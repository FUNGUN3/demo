const button = document.querySelector("#helloButton");
const counter = document.querySelector("#counter");
let count = 0;

button.addEventListener("click", () => {
  count++;
  counter.textContent = "Нажатий: " + count;
  if (count >= 5) {
    counter.classList.add("text-danger");
  }
});