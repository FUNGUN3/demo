import re
from flask import Flask, render_template, request, redirect, url_for, flash

from db import Database, RoomRepository

app = Flask(__name__)
app.secret_key = "test-secret"

rooms_repository = RoomRepository(Database())


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/rooms")
def rooms_page():
    rooms = rooms_repository.get_all()
    return render_template("rooms.html", rooms=rooms)


@app.route("/hello", methods=["GET", "POST"])
def hello():
    error = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            error = "Введите имя"
        elif not re.fullmatch(r"[А-Яа-яЁё ]+", name):
            error = "Только кириллица и пробелы"
        else:
            flash(f"Здравствуйте, {name}!", "success")
            return redirect(url_for("hello"))
    return render_template("hello.html", error=error)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
