# Скриншоты к этапу 7

| Файл | Задание | Что показано |
|---|---|---|
| `task1_environment.png` | 1 | venv, requirements.txt, .gitignore, `flask --version` до и после активации, коммит |
| `task2_models.png` | 2 | вывод `models.py`: три заявки, ошибка «Недопустимый статус», объект Room |
| `task3_flask.png` | 3 | страницы `/` и `/about` в браузере |
| `task3_syntax_error.png` | 3 | сообщение об ошибке после удаления двоеточия |
| `task4_rooms.png` | 4 | `/rooms` со списком из Python, общая шапка и подвал, кинозал выделен жирным |
| `task5_forms.png` | 5 | ошибка при латинице и зелёное приветствие при кириллице |
| `task6_database.png` | 6 | `db_test.py`, INSERT через psql и `/rooms` с новым помещением из PostgreSQL |
