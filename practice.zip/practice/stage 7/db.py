import psycopg2
from psycopg2.extras import RealDictCursor

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "conferences",
    "user": "conf_user",
    "password": "conf_pass",
}


class Database:
    """Подключение к PostgreSQL и выполнение запросов."""

    def __init__(self, config=None):
        self.config = config or DB_CONFIG

    def query(self, sql, params=()):
        """Выполняет SQL и возвращает строки в виде словарей."""
        connection = psycopg2.connect(**self.config)
        try:
            with connection:
                with connection.cursor(cursor_factory=RealDictCursor) as cursor:
                    cursor.execute(sql, params)
                    return cursor.fetchall()
        finally:
            connection.close()


class RoomRepository:
    """Чтение помещений из таблицы rooms."""

    def __init__(self, database):
        self.database = database

    def get_all(self):
        return self.database.query(
            "SELECT id, name, room_type FROM rooms ORDER BY id"
        )
