class Booking:
    """Заявка на бронирование помещения."""
    STATUSES = ("Новая", "Мероприятие назначено", "Завершено")

    def __init__(self, booking_id, room_name, status="Новая"):
        self.id = booking_id
        self.room_name = room_name
        self.status = status

    def change_status(self, new_status):
        if new_status not in self.STATUSES:
            raise ValueError("Недопустимый статус")
        self.status = new_status

    def describe(self):
        return f"Заявка №{self.id}: {self.room_name} ({self.status})"


class Room:
    def __init__(self, room_id, name, room_type):
        self.id = room_id
        self.name = name
        self.room_type = room_type

    def describe(self):
        return f"{self.name} ({self.room_type})"


if __name__ == "__main__":
    items = [
        Booking(1, "Аудитория «Москва»"),
        Booking(2, "Коворкинг «Сириус»"),
        Booking(3, "Кинозал «Премьер»"),
    ]
    items[0].change_status("Завершено")
    for b in items:
        print(b.describe())

    try:
        items[1].change_status("Отменена")
    except ValueError as e:
        print("Ошибка:", e)

    r = Room(4, "Кинозал «Премьер»", "Кинозал")
    print(r.describe())