// Проверка полей формы прямо в браузере, до отправки на сервер.
// Один и тот же файл подключён к register.html и login.html.
// На регистрации проверяются формат и заполненность,
// на входе — только заполненность (формат логина пользователь может не помнить).

// Правила для пяти полей регистрации. Ключ — значение атрибута name.
const rules = {
    login: {
        test: (value) => /^[A-Za-z0-9]{6,}$/.test(value),
        message: "Только латиница и цифры, не менее 6 символов",
    },
    password: {
        test: (value) => value.length >= 8,
        message: "Пароль должен быть не короче 8 символов",
    },
    full_name: {
        test: (value) => /^[А-Яа-яЁё ]+$/.test(value),
        message: "Только кириллица и пробелы",
    },
    phone: {
        test: (value) => /^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/.test(value),
        message: "Формат: 8(XXX)XXX-XX-XX",
    },
    email: {
        test: (value) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value),
        message: "Формат: name@example.ru",
    },
};

// Показать или убрать ошибку под полем.
// Пустой текст убирает ошибку и красную рамку.
function showError(input, text) {
    const errorBox = input.parentElement.querySelector(".form__error");

    if (errorBox) {
        errorBox.textContent = text;
    }

    input.classList.toggle("is-invalid", text !== "");
}

// Проверить одно поле. Вернуть true, если поле заполнено верно.
// useRules === true — дополнительно проверяем формат по объекту rules.
function checkField(input, useRules) {
    const value = input.value.trim();

    if (value === "") {
        showError(input, "Поле обязательно для заполнения");
        return false;
    }

    const rule = rules[input.name];

    if (useRules && rule && !rule.test(value)) {
        showError(input, rule.message);
        return false;
    }

    showError(input, "");
    return true;
}

// На странице регистрации проверяем формат, на странице входа — только заполненность
const form = document.querySelector("#registerForm") || document.querySelector("#loginForm");
const useRules = form && form.id === "registerForm";

if (form) {
    const inputs = form.querySelectorAll("input");

    // Проверка при уходе с поля
    inputs.forEach((input) => {
        input.addEventListener("blur", () => checkField(input, useRules));

        // Если поле уже подсвечено красным, ошибка исчезает сразу после исправления
        input.addEventListener("input", () => {
            if (input.classList.contains("is-invalid")) {
                checkField(input, useRules);
            }
        });
    });

    // Проверка всех полей перед отправкой
    form.addEventListener("submit", (event) => {
        let allValid = true;

        inputs.forEach((input) => {
            if (!checkField(input, useRules)) {
                allValid = false;
            }
        });

        if (!allValid) {
            event.preventDefault(); // не отправляем форму с ошибками
            form.querySelector(".is-invalid").focus();
        }
    });
}
