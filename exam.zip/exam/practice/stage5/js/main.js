// Счётчик нажатий на главной странице.
// Скрипт подключён в конце body, поэтому все элементы уже есть в DOM.

const helloButton = document.querySelector("#helloButton");
const counter = document.querySelector("#counter");

// Если на странице нет кнопки или счётчика, скрипт просто ничего не делает
if (helloButton && counter) {
    let clicks = 0;

    helloButton.addEventListener("click", () => {
        clicks += 1;
        counter.textContent = "Нажатий: " + clicks;

        // С пятого нажатия класс Bootstrap text-danger делает текст красным
        if (clicks >= 5) {
            counter.classList.add("text-danger");
        }
    });
}
