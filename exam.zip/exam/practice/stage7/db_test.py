"""Проверка подключения Python к PostgreSQL (этап 6)."""

import psycopg2
from psycopg2.extras import RealDictCursor

# Параметры те же, что в app.py
connection = psycopg2.connect(
    host="localhost",
    port=5432,
    dbname="conferences",
    user="conf_user",
    password="conf_pass",
)

try:
    with connection:
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(
                "SELECT id, name, room_type FROM rooms ORDER BY id"
            )
            rooms = cursor.fetchall()

    for room in rooms:
        print(f"{room['id']}. {room['name']} — {room['room_type']}")
finally:
    connection.close()
