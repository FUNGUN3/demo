"""Модели предметной области портала «Конференции.РФ»."""


class Booking:
    """Заявка на бронирование помещения."""

    # Атрибут класса: допустимые статусы одинаковы для всех заявок
    STATUSES = ("Новая", "Мероприятие назначено", "Завершено")

    def __init__(self, booking_id, room_name, status="Новая"):
        # __init__ вызывается при создании объекта
        self.id = booking_id
        self.room_name = room_name
        self.status = status

    def change_status(self, new_status):
        """Изменить статус заявки с проверкой допустимых значений."""
        if new_status not in self.STATUSES:
            raise ValueError("Недопустимый статус")
        self.status = new_status

    def describe(self):
        """Вернуть текстовое описание заявки."""
        return f"Заявка №{self.id}: {self.room_name} ({self.status})"


class Room:
    """Помещение для конференции."""

    def __init__(self, room_id, name, room_type):
        self.id = room_id
        self.name = name
        self.room_type = room_type

    def describe(self):
        """Вернуть строку вида «Кинозал «Премьер» (Кинозал)»."""
        return f"{self.name} ({self.room_type})"


if __name__ == "__main__":
    # Три заявки: у одной сразу меняем статус
    bookings = [
        Booking(1, "Аудитория «Москва»"),
        Booking(2, "Коворкинг «Сириус»"),
        Booking(3, "Кинозал «Премьер»"),
    ]
    bookings[1].change_status("Завершено")

    for booking in bookings:
        print(booking.describe())

    # Проверяем класс Room
    room = Room(4, "Кинозал «Премьер»", "Кинозал")
    print(room.describe())

    # Пробуем недопустимый статус и перехватываем ошибку
    try:
        bookings[0].change_status("Отменена")
    except ValueError as error:
        print("Ошибка:", error)
