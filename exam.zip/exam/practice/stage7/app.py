"""Практическое приложение этапа 7: Flask, шаблоны и PostgreSQL."""

import re

import psycopg2
from flask import Flask, flash, redirect, render_template, request, url_for
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

# Секретный ключ нужен для flash-сообщений и сессий.
# В учебном проекте он записан прямо в коде, в реальном — берётся из переменной окружения.
app.secret_key = "dev-secret-key-conferences"

# Параметры подключения к базе из этапа 6
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "conferences",
    "user": "conf_user",
    "password": "conf_pass",
}


def get_rooms():
    """Получить список помещений из PostgreSQL."""
    connection = psycopg2.connect(**DB_CONFIG)

    try:
        with connection.cursor(cursor_factory=RealDictCursor) as cursor:
            # Значения в SQL передаются через %s, а не через f-строку
            cursor.execute(
                "SELECT id, name, room_type FROM rooms ORDER BY id"
            )
            return cursor.fetchall()
    finally:
        connection.close()


@app.route("/")
def index():
    """Главная страница."""
    return render_template("index.html")


@app.route("/about")
def about():
    """Страница о портале."""
    return render_template("about.html")


@app.route("/rooms")
def rooms_page():
    """Список помещений из базы данных."""
    rooms = get_rooms()
    return render_template("rooms.html", rooms=rooms)


@app.route("/hello", methods=["GET", "POST"])
def hello():
    """Форма приветствия с проверкой имени на сервере."""
    error = ""
    name = ""

    if request.method == "POST":
        name = request.form.get("name", "").strip()

        if not name:
            error = "Введите имя"
        elif not re.fullmatch(r"[А-Яа-яЁё ]+", name):
            error = "Имя должно содержать только кириллицу и пробелы"
        else:
            # Сообщение покажется на странице после redirect
            flash(f"Здравствуйте, {name}!", "success")
            return redirect(url_for("hello"))

    return render_template("hello.html", error=error, name=name)


if __name__ == "__main__":
    app.run(debug=True)
