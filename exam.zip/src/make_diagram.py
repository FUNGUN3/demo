# -*- coding: utf-8 -*-
"""Компактная UML-диаграмма классов (SVG) для системы «Онлайн-магазин».

Стиль — как в образце: монохром, серые шапки классов, короткие подписи
на линиях («Наследование», «Размещает», «Содержит»), без легенды.
Покрывает требования задания: атрибуты и операции с параметрами,
стереотипы, ассоциация, наследование, реализация, агрегация, композиция,
зависимость.
"""

W, H = 920, 780
FONT = "'Times New Roman', Times, Georgia, serif"
INK = "#000000"
EDGE = "#000000"
HEADER = "#D9D9D9"
LH = 16

out = ['<?xml version="1.0" encoding="UTF-8"?>']
out.append(
    f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" '
    f'font-family="{FONT}">'
)
out.append(f'<rect x="0" y="0" width="{W}" height="{H}" fill="#FFFFFF"/>')


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text(x, y, s, size=11.5, anchor="start", bold=False, italic=False,
         fill=INK, halo=False, rotate=None):
    style = f'font-size="{size}" fill="{fill}"'
    if bold:
        style += ' font-weight="bold"'
    if italic:
        style += ' font-style="italic"'
    if halo:
        style += ' stroke="#FFFFFF" stroke-width="3" paint-order="stroke" stroke-linejoin="round"'
    if anchor != "start":
        style += f' text-anchor="{anchor}"'
    tr = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ""
    out.append(f'<text x="{x}" y="{y}" {style}{tr}>{esc(s)}</text>')


class Box:
    def __init__(self, x, y, name, attrs=(), ops=(), stereo=None, w=220):
        self.x, self.y, self.w = x, y, w
        self.name, self.attrs, self.ops = name, list(attrs), list(ops)
        self.stereo = stereo
        self.head = 40 if stereo else 26
        self.ah = (6 + LH * len(self.attrs)) if self.attrs else 0
        self.oh = (6 + LH * len(self.ops)) if self.ops else 0
        self.h = self.head + self.ah + self.oh

    @property
    def left(self):
        return self.x

    @property
    def right(self):
        return self.x + self.w

    @property
    def top(self):
        return self.y

    @property
    def bottom(self):
        return self.y + self.h

    @property
    def cx(self):
        return self.x + self.w / 2

    def draw(self):
        x, y, w, h = self.x, self.y, self.w, self.h
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#FFFFFF" '
                   f'stroke="{EDGE}" stroke-width="1.1"/>')
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{self.head}" fill="{HEADER}" '
                   f'stroke="{EDGE}" stroke-width="1.1"/>')
        cx = x + w / 2
        if self.stereo:
            text(cx, y + 15, self.stereo, size=10, anchor="middle", italic=True)
            text(cx, y + 33, self.name, size=13, anchor="middle", bold=True)
        else:
            text(cx, y + 18, self.name, size=13, anchor="middle", bold=True)
        cy = y + self.head
        if self.attrs:
            out.append(f'<line x1="{x}" y1="{cy}" x2="{x + w}" y2="{cy}" '
                       f'stroke="{EDGE}" stroke-width="1"/>')
            for i, a in enumerate(self.attrs):
                text(x + 8, cy + 15 + i * LH, a, size=11.5)
            cy += self.ah
        if self.ops:
            out.append(f'<line x1="{x}" y1="{cy}" x2="{x + w}" y2="{cy}" '
                       f'stroke="{EDGE}" stroke-width="1"/>')
            for i, o in enumerate(self.ops):
                text(x + 8, cy + 15 + i * LH, o, size=11.5)


boxes = {}


def add(key, x, y, name, **kw):
    boxes[key] = Box(x, y, name, **kw)
    return boxes[key]


# ---------------------------------------------------------------- классы
add("user", 20, 40, "Пользователь", stereo="«abstract»",
    attrs=["# id : int", "# логин : String", "- пароль : String"],
    ops=["+ авторизоваться(логин) : boolean", "+ выйти() : void"])

add("buyer", 20, 260, "Покупатель",
    attrs=["- имя : String", "- телефон : String"],
    ops=["+ оформитьЗаказ() : Заказ", "+ отменитьЗаказ(номер) : boolean"])

add("admin", 330, 40, "Администратор",
    attrs=["- уровеньДоступа : int", "- должность : String"],
    ops=["+ добавитьТовар(товар) : void", "+ изменитьЦену(артикул) : void"])

add("order", 330, 260, "Заказ",
    attrs=["- номер : String", "- дата : Date", "- сумма : Decimal"],
    ops=["+ оплатить() : boolean", "+ изменитьСтатус(статус) : void"])

add("item", 330, 470, "ПозицияЗаказа",
    attrs=["- количество : int", "- цена : Decimal"],
    ops=["+ стоимость() : Decimal"])

add("status", 330, 650, "СтатусЗаказа", stereo="«enumeration»",
    attrs=["НОВЫЙ", "ОПЛАЧЕН", "ДОСТАВЛЕН"])

add("category", 660, 650, "Категория",
    attrs=["- id : int", "- название : String"],
    ops=["+ товары() : List<Товар>"])

add("product", 660, 470, "Товар",
    attrs=["- артикул : String", "- название : String", "- цена : Decimal"],
    ops=["+ вНаличии() : boolean"])

add("paymethod", 660, 40, "СпособОплаты", stereo="«interface»",
    ops=["+ оплатить(сумма) : boolean"])

add("onlinepay", 660, 170, "ОнлайнОплата",
    attrs=["- номерКарты : String"],
    ops=["+ оплатить(сумма) : boolean"])

for b in boxes.values():
    b.draw()

u, b, a = boxes["user"], boxes["buyer"], boxes["admin"]
o, oi, s = boxes["order"], boxes["item"], boxes["status"]
cat, p = boxes["category"], boxes["product"]
pm, on = boxes["paymethod"], boxes["onlinepay"]


# ---------------------------------------------------------------- связи
def marker(kind, tip, direction, size=8):
    x, y = tip
    if kind == "triangle":
        pts = {"up": [(x, y), (x - size / 2, y + size), (x + size / 2, y + size)],
               "down": [(x, y), (x - size / 2, y - size), (x + size / 2, y - size)],
               "left": [(x, y), (x + size, y - size / 2), (x + size, y + size / 2)],
               "right": [(x, y), (x - size, y - size / 2), (x - size, y + size / 2)]}[direction]
        out.append(f'<polygon points="{" ".join(f"{px},{py}" for px, py in pts)}" '
                   f'fill="#FFFFFF" stroke="{EDGE}" stroke-width="1.1"/>')
    elif kind in ("diamond", "diamond_open"):
        l, wd = size + 6, size / 2 + 1
        pts = {"up": [(x, y), (x - wd, y - l / 2), (x, y - l), (x + wd, y - l / 2)],
               "down": [(x, y), (x - wd, y + l / 2), (x, y + l), (x + wd, y + l / 2)],
               "left": [(x, y), (x + l / 2, y - wd), (x + l, y), (x + l / 2, y + wd)],
               "right": [(x, y), (x - l / 2, y - wd), (x - l, y), (x - l / 2, y + wd)]}[direction]
        fill = EDGE if kind == "diamond" else "#FFFFFF"
        out.append(f'<polygon points="{" ".join(f"{px},{py}" for px, py in pts)}" '
                   f'fill="{fill}" stroke="{EDGE}" stroke-width="1.1"/>')
    elif kind == "open":
        pts = {"up": [(x - 4, y + 8), (x, y), (x + 4, y + 8)],
               "down": [(x - 4, y - 8), (x, y), (x + 4, y - 8)],
               "left": [(x + 8, y - 4), (x, y), (x + 8, y + 4)],
               "right": [(x - 8, y - 4), (x, y), (x - 8, y + 4)]}[direction]
        out.append(f'<polyline points="{" ".join(f"{px},{py}" for px, py in pts)}" '
                   f'fill="none" stroke="{EDGE}" stroke-width="1.1" stroke-linejoin="miter"/>')


def edge(points, start_mark=None, end_mark=None, dashed=False, start_dir=None, end_dir=None):
    d_ = "M" + " L".join(f"{x},{y}" for x, y in points)
    dash = ' stroke-dasharray="7 4"' if dashed else ""
    out.append(f'<path d="{d_}" fill="none" stroke="{EDGE}" stroke-width="1.1"{dash} '
               f'stroke-linejoin="round" stroke-linecap="butt"/>')
    if end_mark:
        marker(end_mark, points[-1], end_dir)
    if start_mark:
        marker(start_mark, points[0], start_dir)


def rel(x, y, s, anchor="middle", rotate=None):
    text(x, y, s, size=9.5, anchor=anchor, italic=True, halo=True, rotate=rotate)


def mult(x, y, s, anchor="middle"):
    text(x, y, s, size=9.5, anchor=anchor, bold=True, halo=True)


# 1. наследование: Покупатель -> Пользователь
edge([(b.cx, b.top), (b.cx, u.bottom)], end_mark="triangle", end_dir="up")
rel(b.cx + 8, (b.top + u.bottom) / 2 + 4, "Наследование", anchor="start")

# 2. наследование: Администратор -> Пользователь (обход сверху)
edge([(a.cx, a.top), (a.cx, 18), (u.cx, 18), (u.cx, u.top)],
     end_mark="triangle", end_dir="down")
rel((a.cx + u.cx) / 2, 13, "Наследование")

# 3. ассоциация: Покупатель размещает Заказ
edge([(b.right, 300), (o.left, 300)], end_mark="open", end_dir="right")
mult(b.right + 4, 294, "1", anchor="start")
mult(o.left - 4, 316, "0..*", anchor="end")
rel((b.right + o.left) / 2, 291, "Размещает")

# 4. композиция: Заказ содержит ПозицияЗаказа
edge([(o.cx, o.bottom), (oi.cx, oi.top)], start_mark="diamond", start_dir="down")
mult(o.cx - 8, o.bottom + 22, "1", anchor="end")
mult(oi.cx - 8, oi.top - 8, "1..*", anchor="end")
rel(o.cx + 10, (o.bottom + oi.top) / 2 + 4, "Содержит", anchor="start")

# 5. ассоциация: ПозицияЗаказа ссылается на Товар
edge([(oi.right, 500), (p.left, 500)], end_mark="open", end_dir="right")
mult(oi.right + 4, 514, "1..*", anchor="start")
mult(p.left - 4, 514, "1", anchor="end")
rel((oi.right + p.left) / 2, 486, "Ссылается на")

# 6. агрегация: Категория объединяет Товар
edge([(p.cx, p.bottom), (p.cx, cat.top)], end_mark="diamond_open", end_dir="up")
mult(p.cx - 8, p.bottom + 18, "0..*", anchor="end")
mult(p.cx - 8, cat.top - 8, "1", anchor="end")
rel(p.cx + 10, (p.bottom + cat.top) / 2 + 4, "Принадлежит", anchor="start")

# 7. ассоциация: Заказ оплачивается СпособОплаты
edge([(o.right, 320), (610, 320), (610, 70), (pm.left, 70)],
     end_mark="open", end_dir="right")
mult(o.right + 4, 314, "1", anchor="start")
mult(pm.left - 4, 63, "1", anchor="end")
rel(604, 200, "Оплачивает", rotate=-90)

# 8. реализация интерфейса: ОнлайнОплата -> СпособОплаты
edge([(on.cx, on.top), (on.cx, pm.bottom)], end_mark="triangle", end_dir="up", dashed=True)
rel(on.cx + 8, (on.top + pm.bottom) / 2 + 4, "Реализует", anchor="start")

# 9. зависимость: Заказ использует СтатусЗаказа
edge([(o.left, 340), (290, 340), (290, 690), (s.left, 690)],
     end_mark="open", end_dir="right", dashed=True)
rel(284, 520, "Использует", rotate=-90)

out.append("</svg>")
open("диаграмма_классов.svg", "w", encoding="utf-8").write("\n".join(out))
print("ok", len("\n".join(out)))
