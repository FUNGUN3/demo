# -*- coding: utf-8 -*-
"""Отрисовка ER-диаграмм (нотация Crow's Foot) в PNG без «шума» интерфейса."""

import os
import sys

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from schema import SCHEMAS  # noqa: E402

FONT_DIR = r"C:\Windows\Fonts"
SANS = os.path.join(FONT_DIR, "segoeui.ttf")
SANS_B = os.path.join(FONT_DIR, "segoeuib.ttf")
MONO = os.path.join(FONT_DIR, "consola.ttf")
MONO_B = os.path.join(FONT_DIR, "consolab.ttf")

INK = (24, 26, 32)
GRAY = (108, 114, 126)
LIGHT = (150, 156, 168)
HEAD_BG = (233, 236, 241)
BORDER = (62, 68, 80)
LINE = (70, 76, 88)

HEADER_H = 46
ROW_H = 30
PAD_BOTTOM = 10
SCALE = 2


def font(path, size):
    return ImageFont.truetype(path, int(size * SCALE))


class Box:
    def __init__(self, name, spec):
        self.name = name
        self.x, self.y = spec["pos"]
        self.w = spec["w"]
        self.cols = spec["columns"]
        self.h = HEADER_H + ROW_H * len(self.cols) + PAD_BOTTOM

    @property
    def right(self):
        return self.x + self.w

    @property
    def bottom(self):
        return self.y + self.h

    def point(self, side, frac):
        if side == "left":
            return (self.x, self.y + frac * self.h)
        if side == "right":
            return (self.right, self.y + frac * self.h)
        if side == "top":
            return (self.x + frac * self.w, self.y)
        return (self.x + frac * self.w, self.bottom)


def orth_path(a, aside, b, bside, channel):
    """Ортогональный маршрут от края a до края b."""
    ax, ay = a
    bx, by = b
    a_horiz = aside in ("left", "right")
    b_horiz = bside in ("left", "right")

    if a_horiz and b_horiz:
        if abs(ay - by) < 16:
            return [a, (bx, ay)]
        cx = channel if channel is not None else (ax + bx) / 2
        return [a, (cx, ay), (cx, by), (bx, by)]
    if not a_horiz and not b_horiz:
        if abs(ax - bx) < 16:
            return [a, (ax, by)]
        cy = channel if channel is not None else (ay + by) / 2
        return [a, (ax, cy), (bx, cy), (bx, by)]
    if a_horiz:
        if abs(ay - by) < 16:
            return [a, (bx, ay)]
        return [a, (ax, by), (bx, by)]
    if abs(ax - bx) < 16:
        return [a, (ax, by)]
    return [a, (bx, ay), (bx, by)]


def clean(pts):
    out = [pts[0]]
    for p in pts[1:]:
        if abs(p[0] - out[-1][0]) < 0.01 and abs(p[1] - out[-1][1]) < 0.01:
            continue
        out.append(p)
    return out


class Diagram:
    def __init__(self, schema):
        self.schema = schema
        self.cw, self.ch = schema["canvas"]
        self.title_h = 78
        self.footer_h = 52
        self.w = self.cw
        self.h = self.title_h + self.ch + self.footer_h
        self.img = Image.new("RGB", (self.w * SCALE, self.h * SCALE), "white")
        self.d = ImageDraw.Draw(self.img)
        self.f_title = font(SANS_B, 28)
        self.f_sub = font(SANS, 17)
        self.f_head = font(SANS_B, 23)
        self.f_col = font(MONO, 19)
        self.f_type = font(MONO, 17)
        self.f_tag = font(SANS_B, 13)
        self.f_legend = font(SANS, 15)
        self.boxes = {n: Box(n, s) for n, s in schema["tables"].items()}

    # ------------------------------------------------------------- примитивы
    def text(self, xy, s, fnt, fill=INK, anchor="la"):
        x, y = xy
        self.d.text((x * SCALE, y * SCALE), s, font=fnt, fill=fill, anchor=anchor)

    def line(self, pts, color=LINE, width=1.6):
        self.d.line([(p[0] * SCALE, p[1] * SCALE) for p in pts],
                    fill=color, width=int(width * SCALE), joint="curve")

    def frame(self, x0, y0, x1, y1, fill, outline, width=1.4):
        self.d.rectangle([x0 * SCALE, y0 * SCALE, x1 * SCALE, y1 * SCALE],
                         fill=fill, outline=outline, width=int(width * SCALE))

    # --------------------------------------------------------------- таблица
    def draw_box(self, b, dy):
        x, y = b.x, b.y + dy
        y1 = y + b.h
        self.frame(x, y, b.right, y1, "white", BORDER)
        self.d.rectangle([x * SCALE, y * SCALE, b.right * SCALE, (y + HEADER_H) * SCALE],
                         fill=HEAD_BG, outline=None)
        self.line([(x, y + HEADER_H), (b.right, y + HEADER_H)], color=BORDER, width=1.4)
        self.frame(x, y, b.right, y1, None, BORDER)
        self.text((x + b.w / 2, y + HEADER_H / 2), b.name, self.f_head, anchor="mm")

        for i, (name, ctype, f) in enumerate(b.cols):
            ry = y + HEADER_H + i * ROW_H
            cy = ry + ROW_H / 2
            tag = ""
            if f.get("pk") and f.get("fk"):
                tag = "PK"
            elif f.get("pk"):
                tag = "PK"
            elif f.get("fk"):
                tag = "FK"
            if tag:
                self.text((x + 10, cy), tag, self.f_tag,
                          fill=INK if tag == "PK" else GRAY, anchor="lm")
            self.text((x + 38, cy), name, self.f_col, anchor="lm")
            self.text((b.right - 10, cy), ctype, self.f_type, fill=GRAY, anchor="rm")

    # ---------------------------------------------------------------- связь
    def draw_link(self, spec, dy):
        a = self.boxes[spec["parent"]]
        b = self.boxes[spec["child"]]
        a_pt = a.point(spec["pside"], spec["pfrac"])
        b_pt = b.point(spec["cside"], spec["cfrac"])
        a_pt = (a_pt[0], a_pt[1] + dy)
        b_pt = (b_pt[0], b_pt[1] + dy)
        if "pts" in spec:
            pts = [(p[0], p[1] + dy) for p in spec["pts"]]
        else:
            pts = orth_path(a_pt, spec["pside"], b_pt, spec["cside"], spec.get("channel"))
        pts = clean(pts)
        self.crows_foot(pts[-2], pts[-1])
        self.one_mark(pts[0], pts[1])
        self.line(pts)

    @staticmethod
    def _norm(dx, dy):
        L = max((dx * dx + dy * dy) ** 0.5, 1e-6)
        return dx / L, dy / L

    def crows_foot(self, prev, end):
        dx, dy = self._norm(end[0] - prev[0], end[1] - prev[1])
        px, py = -dy, dx
        base = (end[0] - dx * 20, end[1] - dy * 20)
        s = 10.5
        self.line([base, (end[0] + px * s, end[1] + py * s)])
        self.line([base, end])
        self.line([base, (end[0] - px * s, end[1] - py * s)])

    def one_mark(self, start, nxt):
        dx, dy = self._norm(nxt[0] - start[0], nxt[1] - start[1])
        px, py = -dy, dx
        c = (start[0] + dx * 18, start[1] + dy * 18)
        s = 9
        self.line([(c[0] + px * s, c[1] + py * s), (c[0] - px * s, c[1] - py * s)])

    # ------------------------------------------------------------------ сборка
    def render(self):
        self.text((self.cw / 2, 34), self.schema["title"], self.f_title, anchor="ma")
        self.text((self.cw / 2, 68), self.schema["subtitle"], self.f_sub,
                  fill=GRAY, anchor="ma")
        dy = self.title_h
        for b in self.boxes.values():
            self.draw_box(b, dy)
        for spec in self.schema["links"]:
            self.draw_link(spec, dy)

        ly = self.title_h + self.ch + 22
        self.text((50, ly), "PK — первичный ключ     FK — внешний ключ     "
                            "связь 1 : M (Crow's Foot)",
                  self.f_legend, fill=GRAY)
        self.text((self.cw - 50, ly), "3НФ · Crow's Foot", self.f_legend,
                  fill=LIGHT, anchor="ra")


def build(key, out_dir):
    schema = SCHEMAS[key]
    d = Diagram(schema)
    d.render()
    name = f"ER_задание_{key.replace('.', '_')}.png"
    path = os.path.join(out_dir, name)
    d.img.save(path, dpi=(300, 300))
    print("saved", path, d.img.size)


if __name__ == "__main__":
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
    os.makedirs(out, exist_ok=True)
    for k in SCHEMAS:
        build(k, out)
