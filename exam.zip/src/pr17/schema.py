# -*- coding: utf-8 -*-
"""Схемы БД «Онлайн-магазин» для заданий 9, 9.1, 9.2.

Одна структура задаёт и ER-диаграмму (координаты, ключи), и DDL-скрипт,
поэтому картинки не могут разойтись с реально созданной базой.
"""

# --------------------------------------------------------------------------
# Задание 9 — 4 таблицы
# --------------------------------------------------------------------------
S9 = {
    "key": "9",
    "title": "Задание № 9 — 4 таблицы в 3НФ",
    "subtitle": "БД «Онлайн-магазин»: клиенты, товары, заказы и позиции заказов",
    "canvas": (940, 660),
    "tables": {
        "Клиент": {
            "pos": (40, 60), "w": 340,
            "columns": [
                ("id_клиента", "INTEGER", {"pk": True, "autoinc": True}),
                ("фио", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("email", "TEXT", {"unique": True, "check": "email LIKE '%@%.%'"}),
            ],
        },
        "Заказ": {
            "pos": (500, 60), "w": 370,
            "columns": [
                ("id_заказа", "INTEGER", {"pk": True, "autoinc": True}),
                ("дата_заказа", "TEXT", {"notnull": True, "default": "date('now')"}),
                ("статус", "TEXT", {"notnull": True, "default": "'новый'",
                                    "check": "статус IN ('новый','оплачен','собран','доставлен','отменён')"}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента"),
                                           "on_delete": "CASCADE"}),
            ],
        },
        "Товар": {
            "pos": (40, 400), "w": 340,
            "columns": [
                ("id_товара", "INTEGER", {"pk": True, "autoinc": True}),
                ("наименование", "TEXT", {"notnull": True}),
                ("цена", "REAL", {"notnull": True, "check": "цена > 0"}),
                ("остаток", "INTEGER", {"notnull": True, "default": "0", "check": "остаток >= 0"}),
            ],
        },
        "Позиция_заказа": {
            "pos": (485, 360), "w": 400,
            "columns": [
                ("id_позиции", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "fk": ("Заказ", "id_заказа"),
                                          "on_delete": "CASCADE"}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара")}),
                ("количество", "INTEGER", {"notnull": True, "check": "количество > 0"}),
                ("цена", "REAL", {"notnull": True, "check": "цена >= 0"}),
            ],
            "table_constraints": ["UNIQUE (id_заказа, id_товара)"],
        },
    },
    "links": [
        dict(parent="Клиент", pside="right", pfrac=0.42, child="Заказ", cside="left", cfrac=0.42),
        dict(parent="Заказ", pside="bottom", pfrac=0.5, child="Позиция_заказа", cside="top", cfrac=0.5),
        dict(parent="Товар", pside="right", pfrac=0.55, child="Позиция_заказа", cside="left", cfrac=0.66),
    ],
}


# --------------------------------------------------------------------------
# Задание 9.1 — 10 таблиц
# --------------------------------------------------------------------------
S91 = {
    "key": "9.1",
    "title": "Задание № 9.1 — 10 таблиц в 3НФ",
    "subtitle": "БД «Онлайн-магазин»: каталог, склад, клиенты, заказы и оплата",
    "canvas": (1700, 1010),
    "tables": {
        "Категория": {
            "pos": (50, 60), "w": 300,
            "columns": [
                ("id_категории", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True, "unique": True}),
            ],
        },
        "Поставщик": {
            "pos": (50, 360), "w": 300,
            "columns": [
                ("id_поставщика", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("email", "TEXT", {"unique": True}),
            ],
        },
        "Товар": {
            "pos": (440, 60), "w": 310,
            "columns": [
                ("id_товара", "INTEGER", {"pk": True, "autoinc": True}),
                ("наименование", "TEXT", {"notnull": True}),
                ("цена", "REAL", {"notnull": True, "check": "цена > 0"}),
                ("id_категории", "INTEGER", {"notnull": True, "fk": ("Категория", "id_категории")}),
                ("id_поставщика", "INTEGER", {"notnull": True, "fk": ("Поставщик", "id_поставщика")}),
            ],
        },
        "Склад": {
            "pos": (880, 60), "w": 300,
            "columns": [
                ("id_склада", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True}),
                ("адрес", "TEXT", {"notnull": True}),
            ],
        },
        "Запас": {
            "pos": (880, 360), "w": 300,
            "columns": [
                ("id_запаса", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара")}),
                ("id_склада", "INTEGER", {"notnull": True, "fk": ("Склад", "id_склада")}),
                ("количество", "INTEGER", {"notnull": True, "check": "количество >= 0"}),
            ],
            "table_constraints": ["UNIQUE (id_товара, id_склада)"],
        },
        "Позиция_заказа": {
            "pos": (440, 360), "w": 310,
            "columns": [
                ("id_позиции", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "fk": ("Заказ", "id_заказа"),
                                          "on_delete": "CASCADE"}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара")}),
                ("количество", "INTEGER", {"notnull": True, "check": "количество > 0"}),
                ("цена", "REAL", {"notnull": True, "check": "цена >= 0"}),
            ],
        },
        "Клиент": {
            "pos": (440, 700), "w": 310,
            "columns": [
                ("id_клиента", "INTEGER", {"pk": True, "autoinc": True}),
                ("фио", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("email", "TEXT", {"unique": True, "check": "email LIKE '%@%.%'"}),
            ],
        },
        "Адрес": {
            "pos": (50, 700), "w": 300,
            "columns": [
                ("id_адреса", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента"),
                                           "on_delete": "CASCADE"}),
                ("город", "TEXT", {"notnull": True}),
                ("улица", "TEXT", {"notnull": True}),
                ("дом", "TEXT", {"notnull": True}),
                ("квартира", "TEXT", {}),
            ],
        },
        "Заказ": {
            "pos": (880, 700), "w": 300,
            "columns": [
                ("id_заказа", "INTEGER", {"pk": True, "autoinc": True}),
                ("дата_заказа", "TEXT", {"notnull": True, "default": "date('now')"}),
                ("статус", "TEXT", {"notnull": True, "default": "'новый'",
                                    "check": "статус IN ('новый','оплачен','собран','доставлен','отменён')"}),
                ("сумма", "REAL", {"notnull": True, "check": "сумма >= 0"}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента")}),
            ],
        },
        "Оплата": {
            "pos": (1300, 680), "w": 310,
            "columns": [
                ("id_оплаты", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "unique": True,
                                          "fk": ("Заказ", "id_заказа"), "on_delete": "CASCADE"}),
                ("дата_оплаты", "TEXT", {"notnull": True}),
                ("сумма", "REAL", {"notnull": True, "check": "сумма > 0"}),
                ("способ", "TEXT", {"notnull": True,
                                    "check": "способ IN ('карта','наличные','онлайн')"}),
            ],
        },
    },
    "links": [
        dict(parent="Категория", pside="right", pfrac=0.50, child="Товар", cside="left", cfrac=0.30),
        dict(parent="Поставщик", pside="right", pfrac=0.35, child="Товар", cside="left", cfrac=0.83,
             channel=418),
        dict(parent="Товар", pside="bottom", pfrac=0.50, child="Позиция_заказа", cside="top", cfrac=0.50),
        dict(parent="Товар", pside="right", pfrac=0.55, child="Запас", cside="left", cfrac=0.50,
             channel=815),
        dict(parent="Склад", pside="bottom", pfrac=0.50, child="Запас", cside="top", cfrac=0.50),
        dict(parent="Клиент", pside="right", pfrac=0.42, child="Заказ", cside="left", cfrac=0.36,
             channel=815),
        dict(parent="Клиент", pside="left", pfrac=0.25, child="Адрес", cside="right", cfrac=0.55,
             channel=395),
        dict(parent="Заказ", pside="right", pfrac=0.32, child="Оплата", cside="left", cfrac=0.40,
             channel=1240),
        dict(parent="Заказ", pside="left", pfrac=0.78, child="Позиция_заказа", cside="right", cfrac=0.80,
             channel=810),
    ],
}


# --------------------------------------------------------------------------
# Задание 9.2 — 15 таблиц
# --------------------------------------------------------------------------
S92 = {
    "key": "9.2",
    "title": "Задание № 9.2 — 15 таблиц в 3НФ",
    "subtitle": "БД «Онлайн-магазин»: полная схема с доставкой, курьерами, отзывами и промокодами",
    "canvas": (1930, 1240),
    "tables": {
        "Категория": {
            "pos": (50, 60), "w": 290,
            "columns": [
                ("id_категории", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True, "unique": True}),
            ],
        },
        "Товар": {
            "pos": (435, 60), "w": 290,
            "columns": [
                ("id_товара", "INTEGER", {"pk": True, "autoinc": True}),
                ("наименование", "TEXT", {"notnull": True}),
                ("цена", "REAL", {"notnull": True, "check": "цена > 0"}),
                ("id_категории", "INTEGER", {"notnull": True, "fk": ("Категория", "id_категории")}),
                ("id_поставщика", "INTEGER", {"notnull": True, "fk": ("Поставщик", "id_поставщика")}),
            ],
        },
        "Склад": {
            "pos": (820, 60), "w": 290,
            "columns": [
                ("id_склада", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True}),
                ("адрес", "TEXT", {"notnull": True}),
            ],
        },
        "Филиал": {
            "pos": (1205, 60), "w": 290,
            "columns": [
                ("id_филиала", "INTEGER", {"pk": True, "autoinc": True}),
                ("город", "TEXT", {"notnull": True}),
                ("адрес", "TEXT", {"notnull": True}),
            ],
        },
        "Промокод": {
            "pos": (1590, 60), "w": 290,
            "columns": [
                ("id_промокода", "INTEGER", {"pk": True, "autoinc": True}),
                ("код", "TEXT", {"notnull": True, "unique": True}),
                ("скидка_процент", "INTEGER", {"notnull": True,
                                               "check": "скидка_процент BETWEEN 1 AND 100"}),
                ("срок_действия", "TEXT", {"notnull": True}),
            ],
        },
        "Поставщик": {
            "pos": (50, 400), "w": 290,
            "columns": [
                ("id_поставщика", "INTEGER", {"pk": True, "autoinc": True}),
                ("название", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("email", "TEXT", {"unique": True}),
            ],
        },
        "Позиция_заказа": {
            "pos": (435, 400), "w": 290,
            "columns": [
                ("id_позиции", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "fk": ("Заказ", "id_заказа"),
                                          "on_delete": "CASCADE"}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара")}),
                ("количество", "INTEGER", {"notnull": True, "check": "количество > 0"}),
                ("цена", "REAL", {"notnull": True, "check": "цена >= 0"}),
            ],
        },
        "Запас": {
            "pos": (820, 400), "w": 290,
            "columns": [
                ("id_запаса", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара")}),
                ("id_склада", "INTEGER", {"notnull": True, "fk": ("Склад", "id_склада")}),
                ("количество", "INTEGER", {"notnull": True, "check": "количество >= 0"}),
            ],
            "table_constraints": ["UNIQUE (id_товара, id_склада)"],
        },
        "Курьер": {
            "pos": (1205, 400), "w": 290,
            "columns": [
                ("id_курьера", "INTEGER", {"pk": True, "autoinc": True}),
                ("фио", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("id_филиала", "INTEGER", {"notnull": True, "fk": ("Филиал", "id_филиала")}),
            ],
        },
        "Заказ": {
            "pos": (1590, 400), "w": 290,
            "columns": [
                ("id_заказа", "INTEGER", {"pk": True, "autoinc": True}),
                ("дата_заказа", "TEXT", {"notnull": True, "default": "date('now')"}),
                ("статус", "TEXT", {"notnull": True, "default": "'новый'",
                                    "check": "статус IN ('новый','оплачен','собран','доставлен','отменён')"}),
                ("сумма", "REAL", {"notnull": True, "check": "сумма >= 0"}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента")}),
                ("id_промокода", "INTEGER", {"fk": ("Промокод", "id_промокода")}),
            ],
        },
        "Отзыв": {
            "pos": (50, 740), "w": 290,
            "columns": [
                ("id_отзыва", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_товара", "INTEGER", {"notnull": True, "fk": ("Товар", "id_товара"),
                                          "on_delete": "CASCADE"}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента"),
                                           "on_delete": "CASCADE"}),
                ("оценка", "INTEGER", {"notnull": True, "check": "оценка BETWEEN 1 AND 5"}),
                ("текст", "TEXT", {}),
            ],
        },
        "Клиент": {
            "pos": (820, 740), "w": 290,
            "columns": [
                ("id_клиента", "INTEGER", {"pk": True, "autoinc": True}),
                ("фио", "TEXT", {"notnull": True}),
                ("телефон", "TEXT", {"notnull": True, "unique": True}),
                ("email", "TEXT", {"unique": True, "check": "email LIKE '%@%.%'"}),
            ],
        },
        "Адрес": {
            "pos": (1205, 740), "w": 290,
            "columns": [
                ("id_адреса", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_клиента", "INTEGER", {"notnull": True, "fk": ("Клиент", "id_клиента"),
                                           "on_delete": "CASCADE"}),
                ("город", "TEXT", {"notnull": True}),
                ("улица", "TEXT", {"notnull": True}),
                ("дом", "TEXT", {"notnull": True}),
            ],
        },
        "Оплата": {
            "pos": (1590, 740), "w": 290,
            "columns": [
                ("id_оплаты", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "unique": True,
                                          "fk": ("Заказ", "id_заказа"), "on_delete": "CASCADE"}),
                ("дата_оплаты", "TEXT", {"notnull": True}),
                ("сумма", "REAL", {"notnull": True, "check": "сумма > 0"}),
                ("способ", "TEXT", {"notnull": True,
                                    "check": "способ IN ('карта','наличные','онлайн')"}),
            ],
        },
        "Доставка": {
            "pos": (1205, 1010), "w": 290,
            "columns": [
                ("id_доставки", "INTEGER", {"pk": True, "autoinc": True}),
                ("id_заказа", "INTEGER", {"notnull": True, "unique": True,
                                          "fk": ("Заказ", "id_заказа"), "on_delete": "CASCADE"}),
                ("id_курьера", "INTEGER", {"notnull": True, "fk": ("Курьер", "id_курьера")}),
                ("дата_доставки", "TEXT", {"notnull": True}),
                ("стоимость", "REAL", {"notnull": True, "default": "0", "check": "стоимость >= 0"}),
            ],
        },
    },
    "links": [
        dict(parent="Категория", pside="right", pfrac=0.50, child="Товар", cside="left", cfrac=0.28),
        dict(parent="Поставщик", pside="right", pfrac=0.35, child="Товар", cside="left", cfrac=0.83,
             channel=412),
        dict(parent="Товар", pside="bottom", pfrac=0.50, child="Позиция_заказа", cside="top", cfrac=0.50),
        dict(parent="Товар", pside="right", pfrac=0.55, child="Запас", cside="left", cfrac=0.50,
             channel=772),
        dict(parent="Склад", pside="bottom", pfrac=0.50, child="Запас", cside="top", cfrac=0.50),
        dict(parent="Товар", pside="left", pfrac=0.62, child="Отзыв", cside="right", cfrac=0.60,
             channel=400),
        dict(parent="Клиент", pside="left", pfrac=0.55, child="Отзыв", cside="top", cfrac=0.86,
             pts=[(820, 831), (790, 831), (790, 700), (300, 700), (300, 740)]),
        dict(parent="Клиент", pside="right", pfrac=0.35, child="Заказ", cside="left", cfrac=0.85,
             pts=[(1110, 798), (1150, 798), (1150, 600), (1590, 600)]),
        dict(parent="Клиент", pside="right", pfrac=0.50, child="Адрес", cside="left", cfrac=0.40),
        dict(parent="Заказ", pside="bottom", pfrac=0.40, child="Оплата", cside="top", cfrac=0.40),
        dict(parent="Заказ", pside="right", pfrac=0.55, child="Доставка", cside="right", cfrac=0.55,
             pts=[(1880, 530), (1905, 530), (1905, 1140), (1495, 1140)]),
        dict(parent="Курьер", pside="right", pfrac=0.85, child="Доставка", cside="right", cfrac=0.55,
             pts=[(1470, 576), (1520, 576), (1520, 1100), (1495, 1100)]),
        dict(parent="Филиал", pside="bottom", pfrac=0.50, child="Курьер", cside="top", cfrac=0.50),
        dict(parent="Промокод", pside="bottom", pfrac=0.50, child="Заказ", cside="top", cfrac=0.50),
    ],
}

SCHEMAS = {"9": S9, "9.1": S91, "9.2": S92}


def ddl(text_schema):
    """Генерирует SQL-скрипт создания таблиц по описанию схемы."""
    t = text_schema["tables"]
    lines = ["PRAGMA foreign_keys = ON;", ""]
    for name, tab in t.items():
        cols = tab["columns"]
        wname = max(len(c[0]) for c in cols)
        wtype = max(len(c[1]) for c in cols)
        body = []
        for cname, ctype, f in cols:
            parts = [f"    {cname.ljust(wname)}  {ctype.ljust(wtype)}"]
            if f.get("pk"):
                parts.append("PRIMARY KEY" + (" AUTOINCREMENT" if f.get("autoinc") else ""))
            if f.get("notnull"):
                parts.append("NOT NULL")
            if f.get("unique"):
                parts.append("UNIQUE")
            if f.get("default"):
                parts.append(f"DEFAULT ({f['default']})")
            if f.get("fk"):
                ref_t, ref_c = f["fk"]
                txt = f"REFERENCES {ref_t}({ref_c})"
                if f.get("on_delete"):
                    txt += f" ON DELETE {f['on_delete']}"
                parts.append(txt)
            if f.get("check"):
                parts.append(f"CHECK ({f['check']})")
            body.append(" ".join(parts))
        for tc in tab.get("table_constraints", []):
            body.append("    " + tc)
        lines.append(f"CREATE TABLE {name} (")
        lines.append(",\n".join(body))
        lines.append(");")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"
