# -*- coding: utf-8 -*-
"""Отрисовка «скриншотов» окна SQL-клиента: код запроса + таблица результата."""

import json
import os
import re
import sys

from PIL import Image, ImageDraw, ImageFont

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "out")
FONT_DIR = r"C:\Windows\Fonts"

MONO = os.path.join(FONT_DIR, "consola.ttf")
MONO_B = os.path.join(FONT_DIR, "consolab.ttf")
MONO_I = os.path.join(FONT_DIR, "consolai.ttf")
SANS = os.path.join(FONT_DIR, "segoeui.ttf")
SANS_B = os.path.join(FONT_DIR, "segoeuib.ttf")

INK = (32, 34, 40)
GRAY = (110, 116, 126)
LIGHT = (146, 152, 162)
BORDER = (206, 211, 220)
HEAD_BG = (242, 244, 248)
ZEBRA = (250, 251, 253)
KEY = (0, 51, 179)
STR = (5, 120, 80)
NUM = (154, 63, 24)
COMMENT = (128, 134, 145)
FUNC = (126, 55, 165)
RED = (176, 42, 42)
GREEN = (32, 112, 74)

SCALE = 2
CARD_W = 1180
PAD = 26
GUTTER = 46
LH = 26

KEYWORDS = {
    "SELECT", "FROM", "WHERE", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "ON",
    "GROUP", "BY", "ORDER", "HAVING", "AS", "AND", "OR", "NOT", "NULL", "IS",
    "IN", "BETWEEN", "LIKE", "INSERT", "INTO", "VALUES", "UPDATE", "SET",
    "DELETE", "CREATE", "TABLE", "VIEW", "INDEX", "PRAGMA", "FOREIGN", "KEY",
    "REFERENCES", "PRIMARY", "UNIQUE", "CHECK", "DEFAULT", "AUTOINCREMENT",
    "CASCADE", "CONSTRAINT", "DISTINCT", "UNION", "ALL", "EXISTS", "CASE",
    "WHEN", "THEN", "ELSE", "END", "ASC", "DESC", "INTEGER", "TEXT", "REAL",
    "IF", "REPLACE", "OFFSET", "LIMIT",
}
FUNCS = {"COUNT", "SUM", "AVG", "MIN", "MAX", "DATE", "COALESCE", "ROUND", "IFNULL"}


def f(path, size):
    return ImageFont.truetype(path, int(size * SCALE))


def plural(n):
    if n % 10 == 1 and n % 100 != 11:
        return "строка"
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return "строки"
    return "строк"


def secs(ms):
    ms = max(ms, 0.01)
    if ms < 1:
        return f"{ms:.2f}".replace(".", ",") + " мс"
    if ms < 1000:
        return f"{ms:.1f}".replace(".", ",") + " мс"
    return f"{ms / 1000:.2f}".replace(".", ",") + " с"


class Card:
    def __init__(self, spec):
        self.spec = spec
        self.img = Image.new("RGB", (CARD_W * SCALE, 6000 * SCALE), "white")
        self.d = ImageDraw.Draw(self.img)
        self.f_title = f(SANS_B, 15)
        self.f_meta = f(SANS, 13)
        self.f_code = f(MONO, 18.5)
        self.f_code_b = f(MONO_B, 18.5)
        self.f_code_i = f(MONO_I, 18.5)
        self.f_num = f(MONO, 14)
        self.f_th = f(SANS_B, 14.5)
        self.f_td = f(MONO, 16)
        self.f_status = f(SANS, 13.5)
        self.f_err = f(MONO, 15)
        self.y = 0

    # ------------------------------------------------------------- примитивы
    def text(self, x, y, s, fnt, fill=INK, anchor="la"):
        self.d.text((x * SCALE, y * SCALE), s, font=fnt, fill=fill, anchor=anchor)

    def rect(self, x0, y0, x1, y1, fill=None, outline=None, width=1):
        self.d.rectangle([x0 * SCALE, y0 * SCALE, x1 * SCALE, y1 * SCALE],
                         fill=fill, outline=outline, width=int(width * SCALE))

    def hline(self, x0, x1, y, color=BORDER, width=1):
        self.d.line([(x0 * SCALE, y * SCALE), (x1 * SCALE, y * SCALE)],
                    fill=color, width=int(width * SCALE))

    def vline(self, x, y0, y1, color=BORDER, width=1):
        self.d.line([(x * SCALE, y0 * SCALE), (x * SCALE, y1 * SCALE)],
                    fill=color, width=int(width * SCALE))

    def tw(self, s, fnt):
        return self.d.textlength(s, font=fnt) / SCALE

    # ------------------------------------------------------------ подсветка
    TOKEN = re.compile(r"(--[^\n]*|'(?:[^']|'')*'|\b[0-9]+(?:[.,][0-9]+)?\b|"
                       r"[A-Za-zА-Яа-яЁё_][A-Za-zА-Яа-яЁё_0-9]*|\s+|.)")

    def tokens(self, line):
        out = []
        for m in self.TOKEN.finditer(line):
            t = m.group(0)
            if t.startswith("--"):
                out.append((t, COMMENT, self.f_code_i))
            elif t.startswith("'"):
                out.append((t, STR, self.f_code))
            elif re.fullmatch(r"[0-9]+(?:[.,][0-9]+)?", t):
                out.append((t, NUM, self.f_code))
            elif re.fullmatch(r"[A-Za-zА-Яа-яЁё_][A-Za-zА-Яа-яЁё_0-9]*", t):
                up = t.upper()
                if up in FUNCS:
                    out.append((t, FUNC, self.f_code_b))
                elif up in KEYWORDS:
                    out.append((t, KEY, self.f_code_b))
                else:
                    out.append((t, INK, self.f_code))
            else:
                out.append((t, INK, self.f_code))
        return out

    # ---------------------------------------------------------------- блоки
    def card_header(self, title, note):
        self.rect(0, 0, CARD_W, 48, fill=(238, 241, 246), outline=None)
        self.hline(0, CARD_W, 48, (208, 213, 222), 1)
        # «светофор» окна
        for i, col in enumerate(((236, 108, 100), (238, 183, 84), (110, 190, 110))):
            cx = 22 + i * 17
            r = 5
            self.d.ellipse([(cx - r) * SCALE, (24 - r) * SCALE,
                            (cx + r) * SCALE, (24 + r) * SCALE], fill=col)
        self.text(80, 24, title, self.f_title, anchor="lm")
        self.text(CARD_W - 18, 24, note, self.f_meta, fill=GRAY, anchor="rm")

    def code_block(self, sql, top):
        lines = sql.split("\n")
        avail = CARD_W - PAD - GUTTER - 8 - PAD
        y = top
        num = 0
        for line in lines:
            num += 1
            # мягкая переноска длинных строк, как в редакторе
            chunks, cur = [], ""
            for part in re.findall(r"\s+|\S+", line):
                if self.tw(cur + part, self.f_code) <= avail or not cur.strip():
                    cur += part
                else:
                    chunks.append(cur)
                    cur = "        " + part.lstrip()
            chunks.append(cur)
            first = True
            for chunk in chunks:
                if first:
                    self.text(PAD + GUTTER - 10, y + LH / 2, str(num), self.f_num,
                              fill=LIGHT, anchor="rm")
                x = PAD + GUTTER + 4
                for seg, col, fnt in self.tokens(chunk):
                    self.text(x, y + LH / 2, seg, fnt, fill=col, anchor="lm")
                    x += self.tw(seg, fnt)
                y += LH
                first = False
        return y - LH / 2 + 12

    def grid(self, cols, rows, top, avail):
        """Таблица результата. Возвращает новую координату y."""
        # подбор размера шрифта
        size = 16
        while size >= 11:
            fd = f(MONO, size)
            fh = f(SANS_B, max(10, size - 1.5))
            widths = []
            for j, c in enumerate(cols):
                w = self.tw(c, fh) + 26
                for r in rows:
                    w = max(w, self.tw(str(r[j] if r[j] is not None else "NULL"), fd) + 26)
                widths.append(min(max(w, 74), 330))
            if sum(widths) <= avail:
                break
            size -= 1
        else:
            fd = f(MONO, 11)
            fh = f(SANS_B, 10)
        fd = f(MONO, size)
        fh = f(SANS_B, max(10, size - 1.5))
        hh = 34
        rh = int(size * 1.95)

        # подогнать суммарную ширину под панель
        total = sum(widths)
        widths = [w * avail / total for w in widths]
        x0 = PAD
        y = top
        self.rect(x0, y, x0 + sum(widths), y + hh, fill=HEAD_BG, outline=BORDER, width=1)
        x = x0
        for j, c in enumerate(cols):
            self.text(x + 11, y + hh / 2, c, fh, fill=(30, 34, 42), anchor="lm")
            x += widths[j]
        y += hh
        for i, r in enumerate(rows):
            if i % 2 == 1:
                self.rect(x0, y, x0 + sum(widths), y + rh, fill=ZEBRA, outline=None)
            x = x0
            for j, v in enumerate(r):
                s = "NULL" if v is None else str(v)
                numeric = bool(re.fullmatch(r"-?[0-9]+(?:[.,][0-9]+)?", s))
                if numeric:
                    self.text(x + widths[j] - 11, y + rh / 2, s, fd, anchor="rm")
                else:
                    self.text(x + 11, y + rh / 2, s, fd, anchor="lm",
                              fill=GRAY if v is None else INK)
                x += widths[j]
            y += rh
            self.hline(x0, x0 + sum(widths), y, (228, 231, 237), 1)
        x = x0
        for w in widths[:-1]:
            x += w
            self.vline(x, top, y, (228, 231, 237), 1)
        self.rect(x0, top, x0 + sum(widths), y, outline=BORDER, width=1)
        return y + 14

    def status(self, y, ok, text, right=""):
        col = GREEN if ok else RED
        self.text(PAD, y, ("●  " if ok else "●  ") + text, self.f_status, fill=col)
        if right:
            self.text(CARD_W - PAD, y, right, self.f_status, fill=LIGHT, anchor="ra")
        return y + 24

    def error_panel(self, y, message, right=""):
        h = 44
        self.rect(PAD, y, CARD_W - PAD, y + h, fill=(253, 244, 244),
                  outline=(228, 176, 176), width=1)
        self.text(PAD + 14, y + h / 2, "×  Ошибка: " + message, self.f_err,
                  fill=RED, anchor="lm")
        if right:
            self.text(CARD_W - PAD - 14, y + h / 2, right, self.f_err,
                      fill=(170, 120, 120), anchor="rm")
        return y + h + 12

    # ------------------------------------------------------------------ сборка
    def render(self):
        self.card_header(self.spec["file"],
                         "SQLite 3.45  ·  online_store.db  ·  UTF-8")
        y = 48 + 22
        for bi, b in enumerate(self.spec["blocks"]):
            if bi:
                self.hline(PAD, CARD_W - PAD, y + 4, (232, 235, 241), 1)
                y += 18
            y = self.code_block(b["sql"], y)
            if b["kind"] == "result":
                n = len(b["rows"])
                self.status(y - 2, True, "", "")
                y += 2
                y = self.grid(b["cols"], b["rows"], y, CARD_W - 2 * PAD)
                y = self.status(y, True, f"Запрос выполнен · {n} {plural(n)}",
                                secs(b["ms"]))
            elif b["kind"] == "ok":
                aff = b.get("affected", 0)
                detail = f"затронуто строк: {aff}" if aff else "выполнено без ошибок"
                y = self.status(y, True, f"Оператор выполнен · {detail}", secs(b["ms"]))
            elif b["kind"] == "error":
                y = self.error_panel(y, b["message"], secs(b["ms"]))
            else:
                y = self.status(y, True, "Скрипт создания таблиц выполнен · "
                                         "4 таблицы, 3НФ", "DDL")
            y += 18
        self.rect(0, 0, CARD_W, y + 14, outline=BORDER, width=1)
        self.img = self.img.crop((0, 0, CARD_W * SCALE, int((y + 14) * SCALE)))
        return self.img


def build_all():
    with open(os.path.join(OUT, "data.json"), encoding="utf-8") as fp:
        data = json.load(fp)
    made = []
    for key, cards in data.items():
        for i, card in enumerate(cards, 1):
            img = Card(card).render()
            name = f"SQL_{key.replace('.', '_')}_{i}.png"
            path = os.path.join(OUT, name)
            img.save(path, dpi=(300, 300))
            made.append((name, img.size))
    for n, s in made:
        print(n, s)


if __name__ == "__main__":
    build_all()
