param([string]$Docx, [string]$Pdf)
$ErrorActionPreference = "Stop"
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
$doc = $word.Documents.Open((Resolve-Path $Docx).Path)
$doc.Repaginate()
Write-Output ("pages=" + $doc.ComputeStatistics(2))
$doc.ExportAsFixedFormat((Join-Path (Get-Location) $Pdf), 17)
$doc.Close(0)
$word.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
Write-Output "ok"
