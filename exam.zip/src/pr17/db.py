# -*- coding: utf-8 -*-
"""Создание БД, наполнение данными и выполнение запросов задания.

Все запросы выполняются по-настоящему в SQLite, поэтому таблицы результатов
и тексты ошибок ограничений в отчёте — это фактический вывод СУБД.
"""

import json
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from schema import SCHEMAS, ddl  # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "out")


# ==========================================================================
#  Данные
# ==========================================================================
CLIENTS = [
    (1, "Иванов Иван Иванович", "+7 (916) 120-45-31", "ivanov@mail.ru"),
    (2, "Петрова Анна Владимировна", "+7 (925) 331-78-04", "petrova@yandex.ru"),
    (3, "Смирнов Дмитрий Алексеевич", "+7 (903) 674-12-90", "smirnov@gmail.com"),
    (4, "Кузнецова Ольга Сергеевна", "+7 (968) 205-66-17", "kuznecova@mail.ru"),
    (5, "Соколов Егор Михайлович", "+7 (985) 448-30-52", "sokolov@list.ru"),
    (6, "Морозов Артём Сергеевич", "+7 (916) 555-01-77", "morozov@mail.ru"),
    (7, "Никитина Полина Игоревна", "+7 (926) 811-24-63", "nikitina@yandex.ru"),
]

PRODUCTS = [
    (1, "Apple iPhone 15 128 ГБ", "79990", 12, 1, 1),
    (2, "Samsung Galaxy S24 256 ГБ", "74990", 8, 1, 1),
    (3, "Xiaomi Redmi Note 13 128 ГБ", "21990", 25, 1, 2),
    (4, "Google Pixel 8 128 ГБ", "59990", 5, 1, 2),
    (5, "HONOR X9b 256 ГБ", "24990", 17, 1, 1),
    (6, "Ноутбук ASUS VivoBook 15", "62990", 7, 2, 2),
    (7, "Ноутбук Lenovo IdeaPad 3", "48990", 9, 2, 1),
    (8, "Чехол силиконовый MagSafe", "3490", 120, 3, 3),
    (9, "Зарядное устройство 65 Вт", "2990", 84, 3, 3),
    (10, "Планшет Samsung Galaxy Tab A9", "24990", 6, 4, 3),
]

CATEGORIES = [(1, "Смартфоны"), (2, "Ноутбуки"), (3, "Аксессуары"), (4, "Планшеты")]
SUPPLIERS = [
    (1, 'ООО «МобайлТрейд»', "+7 (495) 120-33-10", "sales@mobiletrade.ru"),
    (2, 'ООО «ТехноЛайн»', "+7 (495) 774-02-56", "info@technoline.ru"),
    (3, 'ИП Кравцов В. А.', "+7 (903) 118-90-42", "kravcov@mail.ru"),
]
WAREHOUSES = [
    (1, "Основной склад", "Москва, ул. Складская, 4"),
    (2, "Склад «Юг»", "Москва, Каширское ш., 61"),
]
STOCKS = [
    (1, 1, 1, 12), (2, 1, 2, 3), (3, 2, 1, 8), (4, 2, 2, 2),
    (5, 3, 1, 25), (6, 3, 2, 14), (7, 4, 1, 5), (8, 5, 1, 17),
    (9, 6, 1, 7), (10, 7, 1, 9), (11, 8, 1, 120), (12, 9, 1, 84),
    (13, 10, 1, 6), (14, 10, 2, 4),
]
ADDRESSES = [
    (1, 1, "Москва", "ул. Ленина", "12", "45"),
    (2, 2, "Москва", "Кутузовский пр-т", "30", "118"),
    (3, 3, "Химки", "ул. Победы", "7", "22"),
    (4, 4, "Москва", "ул. Профсоюзная", "84", "9"),
    (5, 5, "Мытищи", "ул. Мира", "3", None),
    (6, 6, "Москва", "ул. Тверская", "18", "4"),
]

ORDERS = [
    (1, "2026-10-08", "доставлен", "104980", 1),
    (2, "2026-10-14", "доставлен", "74990", 2),
    (3, "2026-10-21", "отменён", "43980", 3),
    (4, "2026-10-29", "доставлен", "101980", 1),
    (5, "2026-11-05", "собран", "59990", 4),
    (6, "2026-11-09", "оплачен", "124970", 2),
    (7, "2026-11-12", "новый", "21990", 5),
    (8, "2026-11-13", "оплачен", "66480", 6),
]

POSITIONS = [
    (1, 1, 1, 1, "79990"), (2, 1, 5, 1, "24990"),
    (3, 2, 2, 1, "74990"),
    (4, 3, 3, 2, "21990"),
    (5, 4, 1, 1, "79990"), (6, 4, 3, 1, "21990"),
    (7, 5, 4, 1, "59990"),
    (8, 6, 2, 1, "74990"), (9, 6, 5, 2, "24990"),
    (10, 7, 3, 1, "21990"),
    (11, 8, 6, 1, "62990"), (12, 8, 8, 1, "3490"),
]

PAYMENTS = [
    (1, 1, "2026-10-08", "104980", "карта"),
    (2, 2, "2026-10-14", "74990", "онлайн"),
    (3, 4, "2026-10-29", "101980", "карта"),
    (4, 5, "2026-11-05", "59990", "онлайн"),
    (5, 6, "2026-11-09", "124970", "карта"),
    (6, 8, "2026-11-13", "66480", "наличные"),
]

BRANCHES = [
    (1, "Москва", "ул. Складская, 4"),
    (2, "Санкт-Петербург", "Лиговский пр-т, 120"),
    (3, "Казань", "ул. Баумана, 44"),
]
COURIERS = [
    (1, "Громов Павел Ильич", "+7 (916) 402-18-55", 1),
    (2, "Данилов Сергей Петрович", "+7 (925) 660-31-07", 1),
    (3, "Ефимова Мария Олеговна", "+7 (921) 774-90-23", 2),
    (4, "Зайцев Никита Андреевич", "+7 (987) 215-66-40", 3),
]
DELIVERIES = [
    (1, 1, 1, "2026-10-09", "0"),
    (2, 2, 2, "2026-10-15", "390"),
    (3, 4, 1, "2026-10-30", "0"),
    (4, 5, 2, "2026-11-06", "390"),
    (5, 6, 3, "2026-11-10", "0"),
    (6, 8, 4, "2026-11-14", "590"),
]
REVIEWS = [
    (1, 1, 1, 5, "Отличный телефон, батарея держит весь день."),
    (2, 5, 1, 4, "Хороший экран, но немного тяжёлый."),
    (3, 2, 2, 5, "Камера супер, рекомендую."),
    (4, 3, 5, 3, "За свои деньги нормально."),
    (5, 7, 4, 4, "Быстрый, тихий, удобная клавиатура."),
    (6, 1, 2, 2, "Пришёл с царапиной на корпусе."),
    (7, 6, 3, 5, "Лёгкий и производительный."),
    (8, 9, 4, 4, "Заряжает быстро, кабель коротковат."),
]
PROMOS = [
    (1, "SALE10", 10, "2026-12-31"),
    (2, "WELCOME15", 15, "2026-12-31"),
    (3, "VIP25", 25, "2026-12-15"),
]
# в заказах 9.2 есть id_промокода
ORDER_PROMO = {1: 1, 2: 2, 6: 1, 8: 3}


# ==========================================================================
#  Блоки запросов
# ==========================================================================
CARDS = {}

# ---------------------------------------------------------------- задание 9
CARDS["9"] = [
    {
        "file": "zadanie_9_shema.sql",
        "title": "Схема БД: 4 таблицы в 3НФ",
        "blocks": [{"sql": None, "ddl": "9"}],
    },
    {
        "file": "zadanie_9_zapros_1.sql",
        "title": "Оператор SELECT · фильтрация BETWEEN",
        "blocks": [{
            "sql": """-- Оператор 1: выборка с соединением и группировкой
SELECT к.фио                          AS клиент,
       COUNT(DISTINCT з.id_заказа)    AS заказов,
       SUM(п.количество * п.цена)     AS сумма
FROM Клиент к
JOIN Заказ з           ON з.id_клиента = к.id_клиента
JOIN Позиция_заказа п  ON п.id_заказа  = з.id_заказа
WHERE з.статус <> 'отменён'
  AND з.дата_заказа BETWEEN '2026-10-01' AND '2026-11-30'
GROUP BY к.id_клиента
ORDER BY сумма DESC;""",
        }],
    },
    {
        "file": "zadanie_9_zapros_2.sql",
        "title": "Операторы INSERT и SELECT · фильтрация LIKE",
        "blocks": [{
            "sql": """-- Оператор 2: добавление строки
INSERT INTO Клиент (фио, телефон, email)
VALUES ('Морозов Артём Сергеевич', '+7 (916) 555-01-77', 'morozov@mail.ru');""",
        }, {
            "sql": """-- Фильтрация 2: шаблонный поиск
SELECT id_клиента, фио, телефон, email
FROM Клиент
WHERE email LIKE '%@mail.ru'
ORDER BY фио;""",
        }],
    },
    {
        "file": "zadanie_9_ogranicheniya.sql",
        "title": "Ограничения БД: контроль при вставке",
        "blocks": [
            {"sql": """INSERT INTO Клиент (фио, телефон, email)
VALUES ('Тестов Т. Т.', '+7 (916) 555-01-77', 'test@mail.ru');"""},
            {"sql": """INSERT INTO Товар (наименование, цена, остаток)
VALUES ('Тестовый товар', -100, 1);"""},
            {"sql": """INSERT INTO Заказ (статус, id_клиента)
VALUES ('новый', 999);"""},
        ],
    },
]

# -------------------------------------------------------------- задание 9.1
CARDS["9.1"] = [
    {
        "file": "zadanie_9_1_zapros_1.sql",
        "title": "SELECT с группировкой и HAVING · UPDATE",
        "blocks": [{
            "sql": """-- Оператор 1: агрегирование, фильтрация HAVING
SELECT к.фио                AS клиент,
       COUNT(з.id_заказа)   AS заказов,
       SUM(з.сумма)         AS всего
FROM Клиент к
JOIN Заказ з ON з.id_клиента = к.id_клиента
GROUP BY к.id_клиента
HAVING SUM(з.сумма) > 100000
ORDER BY всего DESC;""",
        }, {
            "sql": """-- Оператор 2: изменение данных, фильтрация по двум условиям
UPDATE Оплата
SET способ = 'онлайн'
WHERE способ = 'карта' AND сумма > 100000;

SELECT id_оплаты, id_заказа, сумма, способ
FROM Оплата
WHERE способ = 'онлайн'
ORDER BY сумма DESC;""",
        }],
    },
    {
        "file": "zadanie_9_1_zapros_2.sql",
        "title": "Фильтрации BETWEEN и LIKE",
        "blocks": [{
            "sql": """-- Фильтрация 1: диапазон дат
SELECT id_заказа, дата_заказа, статус, сумма
FROM Заказ
WHERE дата_заказа BETWEEN '2026-10-15' AND '2026-11-10'
ORDER BY дата_заказа;""",
        }, {
            "sql": """-- Фильтрация 2: шаблон в наименовании
SELECT id_товара, наименование, цена
FROM Товар
WHERE наименование LIKE '%Galaxy%'
ORDER BY цена DESC;""",
        }],
    },
    {
        "file": "zadanie_9_1_zapros_3.sql",
        "title": "Подзапрос с IN · DELETE",
        "blocks": [{
            "sql": """-- Фильтрация 3: IN + подзапрос
SELECT т.id_товара, т.наименование, кат.название AS категория, т.цена
FROM Товар т
JOIN Категория кат ON кат.id_категории = т.id_категории
WHERE т.id_категории IN (
        SELECT id_категории FROM Категория WHERE название IN ('Смартфоны', 'Планшеты')
      )
ORDER BY т.цена DESC;""",
        }, {
            "sql": """-- Фильтрация 4: пустое значение (IS NULL)
SELECT id_адреса, id_клиента, город, улица, дом, квартира
FROM Адрес
WHERE квартира IS NULL;""",
        }, {
            "sql": """-- Оператор 3: удаление найденной строки
DELETE FROM Адрес
WHERE квартира IS NULL;""",
        }, {
            "sql": """SELECT id_адреса, id_клиента, город, улица, дом, квартира
FROM Адрес
ORDER BY id_адреса;""",
        }],
    },
    {
        "file": "zadanie_9_1_zapros_4.sql",
        "title": "Представление, индекс и вставка",
        "blocks": [{
            "sql": """-- Оператор 4: представление (VIEW)
CREATE VIEW Выручка_по_категориям AS
SELECT кат.название                     AS категория,
       COUNT(DISTINCT з.id_заказа)      AS заказов,
       SUM(п.количество * п.цена)       AS выручка
FROM Позиция_заказа п
JOIN Товар т     ON т.id_товара = п.id_товара
JOIN Категория кат ON кат.id_категории = т.id_категории
JOIN Заказ з     ON з.id_заказа = п.id_заказа
WHERE з.статус <> 'отменён'
GROUP BY кат.id_категории;

SELECT * FROM Выручка_по_категориям
ORDER BY выручка DESC;""",
        }, {
            "sql": """-- Оператор 5: индекс для ускорения фильтрации по дате
CREATE INDEX idx_заказ_дата ON Заказ (дата_заказа);

-- Оператор 6: добавление склада
INSERT INTO Склад (название, адрес)
VALUES ('Склад «Восток»', 'Москва, ш. Энтузиастов, 31');

SELECT id_склада, название, адрес FROM Склад;""",
        }],
    },
    {
        "file": "zadanie_9_1_ogranicheniya.sql",
        "title": "Проверка ограничений (4 ограничения)",
        "blocks": [
            {"sql": """INSERT INTO Клиент (фио, телефон, email)
VALUES ('Тестов Т. Т.', '+7 (916) 120-45-31', 'test@mail.ru');"""},
            {"sql": """INSERT INTO Товар (наименование, цена, id_категории, id_поставщика)
VALUES ('Тестовый товар', 0, 1, 1);"""},
            {"sql": """INSERT INTO Товар (наименование, цена, id_категории, id_поставщика)
VALUES ('Тестовый товар', 1000, 99, 1);"""},
            {"sql": """INSERT INTO Оплата (id_заказа, дата_оплаты, сумма, способ)
VALUES (7, '2026-11-13', 5000, 'криптовалюта');"""},
        ],
    },
]

# -------------------------------------------------------------- задание 9.2
CARDS["9.2"] = [
    {
        "file": "zadanie_9_2_zapros_1.sql",
        "title": "JOIN · HAVING · фильтрация по статусу",
        "blocks": [{
            "sql": """-- Оператор 1: выручка по клиентам за оплаченные заказы
SELECT к.фио                        AS клиент,
       COUNT(DISTINCT з.id_заказа)  AS заказов,
       SUM(п.количество * п.цена)   AS выручка
FROM Клиент к
JOIN Заказ з          ON з.id_клиента = к.id_клиента
JOIN Позиция_заказа п ON п.id_заказа  = з.id_заказа
WHERE з.статус IN ('оплачен', 'собран', 'доставлен')
GROUP BY к.id_клиента
HAVING SUM(п.количество * п.цена) > 100000
ORDER BY выручка DESC;""",
        }, {
            "sql": """-- Оператор 2: клиенты без заказов (LEFT JOIN + IS NULL)
SELECT к.id_клиента, к.фио, к.телефон
FROM Клиент к
LEFT JOIN Заказ з ON з.id_клиента = к.id_клиента
WHERE з.id_заказа IS NULL
ORDER BY к.фио;""",
        }],
    },
    {
        "file": "zadanie_9_2_zapros_2.sql",
        "title": "BETWEEN · LIKE · ORDER BY",
        "blocks": [{
            "sql": """-- Оператор 3: заказы за период
SELECT з.id_заказа, з.дата_заказа, з.статус, з.сумма, к.фио AS клиент
FROM Заказ з
JOIN Клиент к ON к.id_клиента = з.id_клиента
WHERE з.дата_заказа BETWEEN '2026-10-20' AND '2026-11-13'
  AND з.сумма >= 50000
ORDER BY з.дата_заказа DESC;""",
        }, {
            "sql": """-- Оператор 4: поиск товара по шаблону
SELECT id_товара, наименование, цена, id_категории
FROM Товар
WHERE наименование LIKE '%Ноутбук%'
ORDER BY цена;""",
        }],
    },
    {
        "file": "zadanie_9_2_zapros_3.sql",
        "title": "Подзапросы · UNION ALL",
        "blocks": [{
            "sql": """-- Оператор 5: коррелированный подзапрос EXISTS
SELECT т.id_товара, т.наименование, т.цена
FROM Товар т
WHERE EXISTS (
        SELECT 1 FROM Отзыв о
        WHERE о.id_товара = т.id_товара AND о.оценка = 5
      )
ORDER BY т.цена DESC;""",
        }, {
            "sql": """-- Оператор 6: объединение выборок
SELECT 'доволен' AS мнение, к.фио, о.оценка
FROM Отзыв о JOIN Клиент к ON к.id_клиента = о.id_клиента
WHERE о.оценка >= 4
UNION ALL
SELECT 'недоволен', к.фио, о.оценка
FROM Отзыв о JOIN Клиент к ON к.id_клиента = о.id_клиента
WHERE о.оценка <= 3
ORDER BY оценка DESC, фио;""",
        }],
    },
    {
        "file": "zadanie_9_2_zapros_4.sql",
        "title": "INSERT · UPDATE · DELETE",
        "blocks": [{
            "sql": """-- Оператор 7: новый отзыв
INSERT INTO Отзыв (id_товара, id_клиента, оценка, текст)
VALUES (4, 6, 5, 'Камера и экран на высоте.');

-- Оператор 8: смена статуса заказа
UPDATE Заказ
SET статус = 'доставлен'
WHERE id_заказа = 7 AND статус = 'новый';

-- Оператор 9: удаление отзыва с низкой оценкой
DELETE FROM Отзыв
WHERE оценка < 3;

SELECT id_отзыва, id_товара, id_клиента, оценка
FROM Отзыв ORDER BY id_отзыва;""",
        }],
    },
    {
        "file": "zadanie_9_2_zapros_5.sql",
        "title": "Представление · индекс · агрегаты",
        "blocks": [{
            "sql": """-- Оператор 10: представление по доставкам
CREATE VIEW Доставки_курьеров AS
SELECT кур.фио                AS курьер,
       ф.город                AS филиал,
       COUNT(д.id_доставки)   AS доставок,
       SUM(д.стоимость)       AS транспортные
FROM Курьер кур
JOIN Филиал ф     ON ф.id_филиала = кур.id_филиала
LEFT JOIN Доставка д ON д.id_курьера = кур.id_курьера
GROUP BY кур.id_курьера;

SELECT * FROM Доставки_курьеров ORDER BY доставок DESC;""",
        }, {
            "sql": """-- Индекс + сводка по складам
CREATE INDEX idx_запас_товар ON Запас (id_товара);

SELECT ск.название                AS склад,
       COUNT(зп.id_запаса)        AS позиций,
       SUM(зп.количество)         AS единиц
FROM Склад ск
JOIN Запас зп ON зп.id_склада = ск.id_склада
GROUP BY ск.id_склада;""",
        }],
    },
    {
        "file": "zadanie_9_2_ogranicheniya.sql",
        "title": "Проверка ограничений (10 ограничений)",
        "blocks": [
            {"sql": """INSERT INTO Клиент (id_клиента, фио, телефон)
VALUES (1, 'Дубль Д. Д.', '+7 (900) 000-00-01');"""},
            {"sql": """INSERT INTO Клиент (фио, телефон, email)
VALUES ('Тестов Т. Т.', '+7 (916) 120-45-31', 'test@mail.ru');"""},
            {"sql": """INSERT INTO Клиент (фио) VALUES (NULL);"""},
            {"sql": """INSERT INTO Товар (наименование, цена, id_категории, id_поставщика)
VALUES ('Тестовый товар', -1, 1, 1);"""},
            {"sql": """INSERT INTO Товар (наименование, цена, id_категории, id_поставщика)
VALUES ('Тестовый товар', 1000, 99, 1);"""},
            {"sql": """INSERT INTO Заказ (статус, сумма, id_клиента)
VALUES ('в обработке', 1000, 1);"""},
            {"sql": """INSERT INTO Оплата (id_заказа, дата_оплаты, сумма, способ)
VALUES (1, '2026-11-13', 1000, 'карта');"""},
            {"sql": """INSERT INTO Запас (id_товара, id_склада, количество)
VALUES (1, 1, 5);"""},
            {"sql": """INSERT INTO Отзыв (id_товара, id_клиента, оценка)
VALUES (1, 1, 7);"""},
            {"sql": """INSERT INTO Промокод (код, скидка_процент, срок_действия)
VALUES ('SUPER', 150, '2026-12-31');"""},
        ],
    },
]


# ==========================================================================
#  Создание и наполнение
# ==========================================================================
def create(key):
    con = sqlite3.connect(":memory:")
    con.executescript(ddl(SCHEMAS[key]))
    con.execute("PRAGMA foreign_keys = ON")
    if key != "9":
        con.executemany("INSERT INTO Категория VALUES (?,?)", CATEGORIES)
        con.executemany("INSERT INTO Поставщик VALUES (?,?,?,?)", SUPPLIERS)
    con.executemany("INSERT INTO Клиент (id_клиента, фио, телефон, email) VALUES (?,?,?,?)",
                    CLIENTS[:5] if key == "9" else CLIENTS)

    if key == "9":
        con.executemany(
            "INSERT INTO Товар (id_товара, наименование, цена, остаток) VALUES (?,?,?,?)",
            [(p[0], p[1], p[2], p[3]) for p in PRODUCTS])
        con.executemany(
            "INSERT INTO Заказ (id_заказа, дата_заказа, статус, id_клиента) VALUES (?,?,?,?)",
            [(o[0], o[1], o[2], o[4]) for o in ORDERS if o[4] <= 5])
        con.executemany("INSERT INTO Позиция_заказа VALUES (?,?,?,?,?)",
                        [p for p in POSITIONS if p[1] <= 7])
        return con

    con.executemany(
        "INSERT INTO Товар (id_товара, наименование, цена, id_категории, id_поставщика) "
        "VALUES (?,?,?,?,?)",
        [(p[0], p[1], p[2], p[4], p[5]) for p in PRODUCTS])
    con.executemany("INSERT INTO Склад VALUES (?,?,?)", WAREHOUSES)
    con.executemany("INSERT INTO Запас VALUES (?,?,?,?)", STOCKS)

    if key == "9.1":
        con.executemany("INSERT INTO Адрес VALUES (?,?,?,?,?,?)", ADDRESSES)
        con.executemany(
            "INSERT INTO Заказ (id_заказа, дата_заказа, статус, сумма, id_клиента) "
            "VALUES (?,?,?,?,?)", ORDERS)
    else:
        con.executemany("INSERT INTO Адрес VALUES (?,?,?,?,?)",
                        [a[:5] for a in ADDRESSES])
        con.executemany("INSERT INTO Промокод VALUES (?,?,?,?)", PROMOS)
        con.executemany(
            "INSERT INTO Заказ (id_заказа, дата_заказа, статус, сумма, id_клиента, id_промокода) "
            "VALUES (?,?,?,?,?,?)",
            [(o[0], o[1], o[2], o[3], o[4], ORDER_PROMO.get(o[0])) for o in ORDERS])

    con.executemany("INSERT INTO Позиция_заказа VALUES (?,?,?,?,?)", POSITIONS)
    con.executemany("INSERT INTO Оплата VALUES (?,?,?,?,?)", PAYMENTS)

    if key == "9.1":
        return con

    con.executemany("INSERT INTO Филиал VALUES (?,?,?)", BRANCHES)
    con.executemany("INSERT INTO Курьер VALUES (?,?,?,?)", COURIERS)
    con.executemany("INSERT INTO Доставка VALUES (?,?,?,?,?)", DELIVERIES)
    con.executemany("INSERT INTO Отзыв VALUES (?,?,?,?,?)", REVIEWS)
    con.commit()
    return con


def fmt(v):
    if v is None:
        return None
    if isinstance(v, float):
        return f"{v:.2f}".replace(".", ",")
    return str(v)


def split_sql(sql):
    parts, buf, q = [], [], None
    for ch in sql:
        if q:
            buf.append(ch)
            if ch == q:
                q = None
        elif ch in "'\"":
            q = ch
            buf.append(ch)
        elif ch == ";":
            s = "".join(buf).strip()
            if s:
                parts.append(s)
            buf = []
        else:
            buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        parts.append(tail)
    return parts


def run_block(con, block):
    if "ddl" in block:
        return {"kind": "ddl", "sql": ddl(SCHEMAS[block["ddl"]]).rstrip(), "n": 1}
    sql = block["sql"].strip()
    stmts = split_sql(sql)
    t0 = time.perf_counter()
    cols, rows, affected, n = None, None, 0, 0
    try:
        for st in stmts:
            cur = con.execute(st)
            n += 1
            if cur.description is not None:
                cols = [d[0] for d in cur.description]
                rows = cur.fetchall()
            elif cur.rowcount and cur.rowcount > 0:
                affected += cur.rowcount
        con.commit()
        dt = (time.perf_counter() - t0) * 1000
        if cols is not None:
            return {"kind": "result", "sql": sql, "cols": cols,
                    "rows": [[fmt(v) for v in r] for r in rows],
                    "ms": round(dt, 1), "n": n, "affected": affected}
        return {"kind": "ok", "sql": sql, "ms": round(dt, 1), "n": n,
                "affected": affected}
    except Exception as e:  # noqa: BLE001
        con.rollback()
        dt = (time.perf_counter() - t0) * 1000
        return {"kind": "error", "sql": sql, "message": str(e),
                "ms": round(dt, 1), "n": n + 1}


def main():
    os.makedirs(OUT, exist_ok=True)
    data = {}
    for key in ("9", "9.1", "9.2"):
        con = create(key)
        cards = []
        for card in CARDS[key]:
            blocks = []
            for b in card["blocks"]:
                blocks.append(run_block(con, b))
            cards.append({"file": card["file"], "title": card["title"], "blocks": blocks})
        data[key] = cards
    with open(os.path.join(OUT, "data.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)

    # контроль: показать, что запросы действительно вернули строки
    for key, cards in data.items():
        print("=" * 70)
        print("Задание", key)
        for c in cards:
            for b in c["blocks"]:
                if b["kind"] == "result":
                    print(f"  {c['file']}: {len(b['rows'])} строк, "
                          f"{len(b['cols'])} колонок — " + " | ".join(b["cols"]))
                elif b["kind"] == "error":
                    print(f"  {c['file']}: ошибка — {b['message']}")
                elif b["kind"] == "ok":
                    print(f"  {c['file']}: OK, строк {b['affected']}")


if __name__ == "__main__":
    main()
