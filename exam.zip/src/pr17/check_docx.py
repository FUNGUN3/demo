# -*- coding: utf-8 -*-
"""Проверка собранного DOCX: структура, рисунки, подписи."""

import os
import zipfile

from docx import Document
from docx.enum.section import WD_ORIENT

import content

path = os.path.join(content.BASE, "Отчет_ПР1.7_3НФ_ER-диаграммы.docx")
doc = Document(path)

print("секций:", len(doc.sections))
for i, s in enumerate(doc.sections):
    orient = "landscape" if s.orientation == WD_ORIENT.LANDSCAPE else "portrait"
    print(f"  {i}: {orient} {s.page_width.cm:.1f}x{s.page_height.cm:.1f} см")

paras = doc.paragraphs
print("абзацев:", len(paras), "таблиц:", len(doc.tables))

pics = [p for p in paras if p._p.findall(
    ".//{http://schemas.openxmlformats.org/drawingml/2006/main}blip")]
print("рисунков:", len(pics))

caps = [p.text for p in paras if p.text.startswith("Рисунок")]
print("подписей:", len(caps))
for c in caps:
    print("  ", c[:70])

with zipfile.ZipFile(path) as z:
    media = [n for n in z.namelist() if n.startswith("word/media/")]
print("файлов изображений:", len(media))

h1 = [p.text for p in paras if p.style.name == "Heading 1"]
print("заголовки:", h1)
