﻿$ErrorActionPreference = 'Stop'
$path = 'C:\Users\user\Desktop\ДИАГРМАМЫ\Отчет_ПР1.7_3НФ_ER-диаграммы.docx'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
    $doc = $word.Documents.Open($path, $false, $true)
    $doc.Repaginate()
    Start-Sleep -Milliseconds 500
    $pages = $doc.ComputeStatistics(2)
    $lastPage = $doc.Content.Information(3)
    $rng = $doc.Range()
    $rng.Collapse(0)
    $endPage = $rng.Information(3)
    Write-Output "pages=$pages contentLastPage=$lastPage endPage=$endPage"
    $doc.Close($false)
} finally {
    $word.Quit()
}
