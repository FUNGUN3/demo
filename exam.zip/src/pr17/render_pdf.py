# -*- coding: utf-8 -*-
"""Сборка отчёта ПР 1.7 в PDF (PyMuPDF) из общего содержания content.py."""

import os

import fitz
from PIL import Image

import content

CM = 28.3464567

FONT_FILES = {
    "normal": os.path.join(os.environ["WINDIR"], "Fonts", "times.ttf"),
    "bold": os.path.join(os.environ["WINDIR"], "Fonts", "timesbd.ttf"),
    "italic": os.path.join(os.environ["WINDIR"], "Fonts", "timesi.ttf"),
    "bolditalic": os.path.join(os.environ["WINDIR"], "Fonts", "timesbi.ttf"),
}
FONT_IDS = {"normal": "F0", "bold": "F1", "italic": "F2", "bolditalic": "F3"}
FONTS = {k: fitz.Font(fontfile=v) for k, v in FONT_FILES.items()}

BODY = 14.0
ASCENT = 0.891

PDF_NAME = "Отчет_ПР1.7_3НФ_ER-диаграммы.pdf"

doc = fitz.open()
page = None
geom = None          # (ширина, высота, лево, право, верх, низ)
y = 0.0
fig_no = 0
page_no = 0


def tw(s, style="normal", size=BODY):
    return FONTS[style].text_length(s, size)


def draw(x, baseline, s, style="normal", size=BODY):
    page.insert_text((x, baseline), s, fontname=FONT_IDS[style],
                     fontfile=FONT_FILES[style], fontsize=size,
                     color=(0, 0, 0))


def new_page(landscape=False):
    global page, geom, y, page_no
    if landscape:
        w, h = 29.7 * CM, 21.0 * CM
        left, right, top, bottom = 1.5 * CM, 1.5 * CM, 1.2 * CM, 1.2 * CM
    else:
        w, h = 21.0 * CM, 29.7 * CM
        left, right, top, bottom = 3.0 * CM, 1.5 * CM, 2.0 * CM, 2.0 * CM
    page = doc.new_page(width=w, height=h)
    page_no += 1
    geom = (w, h, left, right, top, bottom)
    y = top
    for k, path in FONT_FILES.items():
        page.insert_font(fontname=FONT_IDS[k], fontfile=path)
    if page_no > 1:
        num = str(page_no)
        page.insert_text(((w - tw(num, size=12)) / 2, h - bottom + 24), num,
                         fontname="F0", fontfile=FONT_FILES["normal"],
                         fontsize=12, color=(0, 0, 0))


def avail(left_extra=0.0):
    w, _, left, right, _, _ = geom
    return w - left - right - left_extra


def need(h):
    global y
    _, hgt, _, _, _, bottom = geom
    if h > hgt - geom[4] - bottom:
        return False
    if y + h > hgt - bottom:
        new_page(landscape=(geom[0] > geom[1]))
        return True
    return False


# ------------------------------------------------------------------ абзацы
def tokenize(runs):
    tokens = []
    for text, style in runs:
        parts = text.split(" ")
        for i, part in enumerate(parts):
            if i:
                tokens.append((" ", style))
            if part:
                tokens.append((part, style))
    return tokens


def wrap(tokens, width, size=BODY):
    lines, cur, cur_w = [], [], 0.0
    for tok, style in tokens:
        if tok == " ":
            if not cur:
                continue
            w = tw(" ", style, size)
            cur.append((" ", style, w))
            cur_w += w
            continue
        w = tw(tok, style, size)
        if cur and cur_w + w > width:
            while cur and cur[-1][0] == " ":
                cur_w -= cur.pop()[2]
            lines.append((cur, cur_w))
            cur, cur_w = [], 0.0
        cur.append((tok, style, w))
        cur_w += w
    while cur and cur[-1][0] == " ":
        cur_w -= cur.pop()[2]
    if cur:
        lines.append((cur, cur_w))
    return lines


def put_line(x, width, line, natural, align, size, leading):
    gaps = sum(1 for t in line if t[0] == " ")
    extra = 0.0
    if align == "justify" and gaps and natural < width:
        extra = (width - natural) / gaps
    elif align == "center":
        x += (width - natural) / 2
    cx = x
    base = y + (leading - size) / 2 + ASCENT * size
    for tok, style, w in line:
        if tok == " ":
            cx += w + extra
        else:
            draw(cx, base, tok, style, size)
            cx += w


def para(runs, indent=1.25 * CM, align="justify", left_extra=0.0,
         space_before=0.0, space_after=0.0, size=BODY, keep_next=False):
    global y
    if isinstance(runs, str):
        runs = [(runs, "normal")]
    leading = size * 1.5
    if space_before:
        need(space_before + leading)
        y += space_before
    indent_px = indent
    width = avail(left_extra)
    lines = wrap(tokenize(runs), width - indent_px, size)
    if not lines:
        y += leading
        return
    need(len(lines) * leading if keep_next else min(2, len(lines)) * leading)
    for i, (line, natural) in enumerate(lines):
        if y + leading > geom[1] - geom[5]:
            new_page(landscape=(geom[0] > geom[1]))
        last = i == len(lines) - 1
        x = geom[2] + left_extra + (indent_px if i == 0 else 0.0)
        wline = width - (indent_px if i == 0 else 0.0)
        line_align = "left" if (last and align == "justify") else align
        put_line(x, wline, line, natural, line_align, size, leading)
        y += leading
    y += space_after


def heading(text, new_page_flag=False):
    global y
    if new_page_flag:
        new_page(landscape=(geom[0] > geom[1]))
    need(3 * 24)
    y += 12
    para([(text, "bold")], indent=0.0, align="left", space_after=6, size=16,
         keep_next=True)


def bullet(runs):
    global y
    if isinstance(runs, str):
        runs = [(runs, "normal")]
    leading = BODY * 1.5
    need(2 * leading)
    draw(geom[2] + 0.75 * CM, y + (leading - BODY) / 2 + ASCENT * BODY, "–",
         "normal", BODY)
    para(runs, indent=0.0, left_extra=1.25 * CM)


def figure(path, caption, width_cm):
    global y, fig_no
    with Image.open(path) as im:
        iw, ih = im.size
    wpt = width_cm * CM
    hpt = wpt * ih / iw
    maxh = geom[1] - geom[4] - geom[5] - 3 * 16.5
    if hpt > maxh:
        wpt *= maxh / hpt
        hpt = maxh
    cap = f"Рисунок {fig_no + 1} — {caption}"
    cap_lines = wrap(tokenize([(cap, "italic")]), avail(), 11)
    cap_h = len(cap_lines) * 16.5 + 10
    need(hpt + 5 + cap_h)
    x = geom[2] + (avail() - wpt) / 2
    page.insert_image(fitz.Rect(x, y, x + wpt, y + hpt), filename=path)
    y += hpt + 5
    fig_no += 1
    para([(cap, "italic")], indent=0.0, align="center", space_after=10, size=11)


def table(rows, widths_cm):
    global y
    widths = [w * CM for w in widths_cm]
    pad, fs, lead = 4.0, 9.5, 11.0
    heights = []
    for row in rows:
        n = 1
        for val, cw in zip(row, widths):
            n = max(n, len(wrap(tokenize([(val, "normal")]), cw - 2 * pad, fs)))
        heights.append(n * lead + 2 * pad)
    need(sum(heights) + 10)
    y += 2
    x0 = geom[2]
    for r, row in enumerate(rows):
        hrow = heights[r]
        cx = x0
        for c, val in enumerate(row):
            cw = widths[c]
            page.draw_rect(fitz.Rect(cx, y, cx + cw, y + hrow),
                           color=(0.4, 0.4, 0.4), width=0.6)
            style = "bold" if r == 0 else "normal"
            lines = wrap(tokenize([(val, style)]), cw - 2 * pad, fs)
            ty = y + pad
            for line, natural in lines:
                total = sum(t[2] for t in line)
                tx = cx + (cw - total) / 2 if r == 0 else cx + pad
                for tok, st, w in line:
                    if tok == " ":
                        tx += w
                    else:
                        page.insert_text((tx, ty + fs * 0.86), tok,
                                         fontname=FONT_IDS[st],
                                         fontfile=FONT_FILES[st], fontsize=fs,
                                         color=(0, 0, 0))
                        tx += w
                ty += lead
            cx += cw
        y += hrow
    y += 8


# ================================================================== титул
new_page()
for text, size, bold, before in content.TITLE:
    y += before
    para([(text, "bold" if bold else "normal")], indent=0.0, align="center",
         space_after=6, size=size)

for line in content.AUTHOR:
    para([(line, "normal")], indent=0.0, align="left", left_extra=9.0 * CM)

y += content.CITY_SPACE
para([(content.CITY, "normal")], indent=0.0, align="center")

# ================================================================== блоки
for block in content.BLOCKS:
    kind = block[0]
    if kind == "section":
        new_page(landscape=(block[1] == "landscape"))
    elif kind == "h1":
        heading(block[1], new_page_flag=block[2].get("new_page", False))
    elif kind == "p":
        para(block[1])
    elif kind == "bullet":
        bullet(block[1])
    elif kind == "bullet_b":
        bullet([(block[1][0], "bold"), (block[1][1], "normal")])
    elif kind == "fig":
        figure(block[1], block[2], block[3])
    elif kind == "table":
        table(block[1], block[2])
    else:
        raise ValueError(kind)

dest = os.path.join(content.BASE, PDF_NAME)
doc.save(dest, garbage=4, deflate=True)
print("saved", PDF_NAME, "pages:", page_no, "figures:", fig_no)
