# -*- coding: utf-8 -*-
"""Рендер страниц PDF в PNG для визуальной проверки."""

import os
import sys

import fitz

import content

pdf = os.path.join(content.BASE, "Отчет_ПР1.7_3НФ_ER-диаграммы.pdf")
dest = os.path.join(content.BASE, "src", "pr17", "preview")
os.makedirs(dest, exist_ok=True)

doc = fitz.open(pdf)
first = int(sys.argv[1]) if len(sys.argv) > 1 else 1
last = int(sys.argv[2]) if len(sys.argv) > 2 else doc.page_count

for i in range(first - 1, last):
    p = doc[i]
    pix = p.get_pixmap(dpi=100)
    pix.save(os.path.join(dest, f"page_{i + 1:02d}.png"))
print("pages:", doc.page_count, "rendered:", first, "-", last)
