# -*- coding: utf-8 -*-
"""Сборка отчёта ПР 1.7 (DOCX) из общего содержания content.py."""

import os

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt
from PIL import Image

import content

BASE = content.BASE
FONT = "Times New Roman"
DOCX_NAME = "Отчет_ПР1.7_3НФ_ER-диаграммы.docx"

doc = Document()

# ------------------------------------------------------------------ страница
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.top_margin, sec.bottom_margin = Cm(2), Cm(2)
sec.left_margin, sec.right_margin = Cm(3), Cm(1.5)
sec.different_first_page_header_footer = True


def set_font(style, size=14, bold=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(attr), FONT)
    lang = rpr.find(qn("w:lang"))
    if lang is None:
        lang = OxmlElement("w:lang")
        rpr.append(lang)
    lang.set(qn("w:val"), "ru-RU")
    lang.set(qn("w:eastAsia"), "ru-RU")


normal = doc.styles["Normal"]
set_font(normal, 14)
normal.paragraph_format.line_spacing = 1.5
normal.paragraph_format.space_after = Pt(0)
normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
normal.paragraph_format.first_line_indent = Cm(1.25)

for name, size in (("Heading 1", 16), ("Heading 2", 14)):
    st = doc.styles[name]
    set_font(st, size, bold=True)
    st.font.color.rgb = None
    st.paragraph_format.first_line_indent = Cm(0)
    st.paragraph_format.space_before = Pt(12 if name == "Heading 1" else 8)
    st.paragraph_format.space_after = Pt(6)
    st.paragraph_format.line_spacing = 1.5
    st.paragraph_format.keep_with_next = True

# ------------------------------------------------- переносы (как в ПР 1.6)
_settings = doc.settings.element
_anchor = _settings.find(qn("w:defaultTabStop"))
_extra = []
for tag, val in (("w:autoHyphenation", "1"), ("w:hyphenationZone", "284")):
    el = OxmlElement(tag)
    el.set(qn("w:val"), val)
    _extra.append(el)
_extra.append(OxmlElement("w:doNotHyphenateCaps"))
for el in _extra:
    if _anchor is not None:
        _anchor.addprevious(el)
    else:
        _settings.append(el)


def p(parts, *, align=None, first_line=None, left=None, space_before=None,
      space_after=None, size=None, keep=False):
    par = doc.add_paragraph()
    if isinstance(parts, str):
        parts = [(parts, False)]
    for text, bold in parts:
        r = par.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
    if align is not None:
        par.alignment = align
    if first_line is not None:
        par.paragraph_format.first_line_indent = Cm(first_line)
    if left is not None:
        par.paragraph_format.left_indent = Cm(left)
    if space_before is not None:
        par.paragraph_format.space_before = Pt(space_before)
    if space_after is not None:
        par.paragraph_format.space_after = Pt(space_after)
    if keep:
        par.paragraph_format.keep_with_next = True
    return par


def bullet(parts, left=1.25):
    par = doc.add_paragraph()
    par.paragraph_format.left_indent = Cm(left)
    par.paragraph_format.first_line_indent = Cm(-0.5)
    par.paragraph_format.line_spacing = 1.5
    par.paragraph_format.space_after = Pt(0)
    par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if isinstance(parts, str):
        parts = [(parts, False)]
    par.add_run("–\t")
    for text, bold in parts:
        r = par.add_run(text)
        r.bold = bold
    return par


def page_break():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


def page_number_footer(section, first_page=False):
    footer = section.first_page_footer if first_page else section.footer
    footer.is_linked_to_previous = False
    par = footer.paragraphs[0]
    par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    par.paragraph_format.first_line_indent = Cm(0)
    if first_page:
        return
    r1 = par.add_run()
    b = OxmlElement("w:fldChar")
    b.set(qn("w:fldCharType"), "begin")
    r1._r.append(b)
    r2 = par.add_run()
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    r2._r.append(instr)
    r3 = par.add_run()
    e = OxmlElement("w:fldChar")
    e.set(qn("w:fldCharType"), "end")
    r3._r.append(e)
    for r in (r1, r2, r3):
        r.font.size = Pt(12)
        r.font.name = FONT


page_number_footer(sec)
page_number_footer(sec, first_page=True)  # титульная страница без номера

# ------------------------------------------------------------------ рисунки
fig_no = 0
used = 0.0
PAGE_LIMIT = 25.5


def image_size(path):
    with Image.open(path) as im:
        return im.size


def figure(path, caption, width_cm=16.5, max_h=24.6):
    """Вставляет рисунок и подпись, следя за заполнением страницы."""
    global fig_no, used
    w, h = image_size(path)
    h_cm = width_cm * h / w
    if h_cm > max_h:
        width_cm *= max_h / h_cm
        h_cm = max_h
    if used and used + h_cm + 0.95 > PAGE_LIMIT:
        page_break()
        used = 0.0
    pic = doc.add_paragraph()
    pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.paragraph_format.first_line_indent = Cm(0)
    pic.paragraph_format.space_before = Pt(4)
    pic.paragraph_format.space_after = Pt(2)
    pic.paragraph_format.keep_with_next = True
    pic.add_run().add_picture(path, width=Cm(width_cm))
    fig_no += 1
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.first_line_indent = Cm(0)
    cap.paragraph_format.space_after = Pt(10)
    r = cap.add_run(f"Рисунок {fig_no} — {caption}")
    r.italic = True
    r.font.size = Pt(11)
    used += h_cm + 0.95


def landscape_section():
    global used
    s = doc.add_section(WD_SECTION.NEW_PAGE)
    s.orientation = WD_ORIENT.LANDSCAPE
    s.page_width, s.page_height = Cm(29.7), Cm(21)
    s.top_margin, s.bottom_margin = Cm(1.2), Cm(1.2)
    s.left_margin, s.right_margin = Cm(1.5), Cm(1.5)
    page_number_footer(s)
    used = 0.0
    return s


def portrait_section():
    global used
    s = doc.add_section(WD_SECTION.NEW_PAGE)
    s.orientation = WD_ORIENT.PORTRAIT
    s.page_width, s.page_height = Cm(21), Cm(29.7)
    s.top_margin, s.bottom_margin = Cm(2), Cm(2)
    s.left_margin, s.right_margin = Cm(3), Cm(1.5)
    page_number_footer(s)
    used = 0.0
    return s


def heading(text, new_page=False):
    global used
    h = doc.add_heading(text, level=1)
    if new_page:
        h.paragraph_format.page_break_before = True
        used = 0.0
    used += 1.2
    return h


def make_table(rows, widths):
    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for i, row in enumerate(rows):
        tr = table.rows[i]
        tr.cant_split = True
        for j, val in enumerate(row):
            cell = tr.cells[j]
            cell.width = Cm(widths[j])
            par = cell.paragraphs[0]
            par.paragraph_format.first_line_indent = Cm(0)
            par.paragraph_format.line_spacing = 1.0
            par.paragraph_format.space_after = Pt(2)
            par.paragraph_format.space_before = Pt(2)
            run = par.add_run(val)
            run.font.size = Pt(9.5)
            run.font.name = FONT
            if i == 0:
                run.bold = True
                par.alignment = WD_ALIGN_PARAGRAPH.CENTER


# ================================================================== титул
for text, size, bold, before in content.TITLE:
    p([(text, bold)], align=WD_ALIGN_PARAGRAPH.CENTER, first_line=0,
      space_before=before, space_after=6)

for line in content.AUTHOR:
    p(line, align=WD_ALIGN_PARAGRAPH.LEFT, first_line=0, left=9.0)

p(content.CITY, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=0,
  space_before=content.CITY_SPACE)

# ================================================================== блоки
for block in content.BLOCKS:
    kind = block[0]

    if kind == "section":
        if block[1] == "landscape":
            landscape_section()
        else:
            portrait_section()

    elif kind == "h1":
        heading(block[1], new_page=block[2].get("new_page", False))

    elif kind == "p":
        p(block[1])

    elif kind == "bullet":
        bullet(block[1])

    elif kind == "bullet_b":
        bullet([(block[1][0], True), (block[1][1], False)])

    elif kind == "fig":
        figure(block[1], block[2], width_cm=block[3])

    elif kind == "table":
        make_table(block[1], block[2])
        used += 6.0

    else:
        raise ValueError(f"неизвестный блок: {kind}")

dest = os.path.join(BASE, DOCX_NAME)
doc.save(dest)
print("saved", DOCX_NAME, "figures:", fig_no)
