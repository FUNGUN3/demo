# -*- coding: utf-8 -*-
"""Контекстная диаграмма IDEF0 (A-0) и дерево узлов.

Предметная область — «Онлайн-магазин сотовых телефонов».
Диаграмма оформлена в стандартной рамке SADT/IDEF0:
слева — входы (Input), сверху — управление (Control),
справа — выходы (Output), снизу — механизмы (Mechanism).
"""

import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

FONT = "'Times New Roman', Times, serif"
INK = "#000000"
LINE = "#000000"


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.out = ['<?xml version="1.0" encoding="UTF-8"?>']
        self.out.append(
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
            f'viewBox="0 0 {w} {h}" font-family="{FONT}">'
        )
        self.out.append(f'<rect x="0" y="0" width="{w}" height="{h}" fill="#FFFFFF"/>')

    def text(self, x, y, s, size=14, anchor="start", bold=False, italic=False,
             fill=INK):
        style = f'font-size="{size}" fill="{fill}"'
        if bold:
            style += ' font-weight="bold"'
        if italic:
            style += ' font-style="italic"'
        if anchor != "start":
            style += f' text-anchor="{anchor}"'
        self.out.append(f'<text x="{x}" y="{y}" {style}>{esc(s)}</text>')

    def rect(self, x, y, w, h, fill="#FFFFFF", sw=1.2, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.out.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" '
            f'stroke="{LINE}" stroke-width="{sw}"{d}/>'
        )

    def line(self, x1, y1, x2, y2, sw=1.2, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.out.append(
            f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
            f'stroke="{LINE}" stroke-width="{sw}"{d}/>'
        )

    def arrow_head(self, x, y, direction, size=7):
        """Закрашенный треугольник; (x, y) — остриё."""
        if direction == "right":
            pts = [(x, y), (x - size, y - size * 0.7), (x - size, y + size * 0.7)]
        elif direction == "left":
            pts = [(x, y), (x + size, y - size * 0.7), (x + size, y + size * 0.7)]
        elif direction == "down":
            pts = [(x, y), (x - size * 0.7, y - size), (x + size * 0.7, y - size)]
        else:  # up
            pts = [(x, y), (x - size * 0.7, y + size), (x + size * 0.7, y + size)]
        p = " ".join(f"{px:.1f},{py:.1f}" for px, py in pts)
        self.out.append(f'<polygon points="{p}" fill="{LINE}" stroke="{LINE}"/>')

    def arrow(self, points, head_at_end=True, direction=None):
        d = "M" + " L".join(f"{x},{y}" for x, y in points)
        self.out.append(
            f'<path d="{d}" fill="none" stroke="{LINE}" stroke-width="1.3" '
            f'stroke-linejoin="miter"/>'
        )
        if head_at_end:
            self.arrow_head(points[-1][0], points[-1][1], direction)

    def save(self, name):
        self.out.append("</svg>")
        path = os.path.join(BASE, name)
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(self.out))
        print("saved", path)


def wrap(s, max_px, size, k=0.50):
    """Простой перенос строки по оценке ширины символов."""
    words = s.split()
    lines, cur = [], ""
    limit = max_px / (size * k)
    for w in words:
        trial = (cur + " " + w).strip()
        if len(trial) <= limit:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


# =====================================================================
# 1. Контекстная диаграмма A-0
# =====================================================================
W, H = 1120, 1450
c = Canvas(W, H)

FX, FY, FW, FH = 35, 35, 1050, 1380
HEAD = 130          # высота шапки
FOOT = 60           # высота подвала
CX0, CY0 = FX, FY + HEAD
CX1, CY1 = FX + FW, FY + FH - FOOT

# ---------------------------------------------------------------- рамка
c.rect(FX, FY, FW, FH, sw=1.6)
c.rect(CX0, CY0, FW, CY1 - CY0, sw=1.4)

# ---------------------------------------------------------------- шапка
COLS = [FX, FX + 145, FX + 445, FX + 545, FX + 660, FX + 810, FX + 900, FX + FW]
ROWS = [FY, FY + 33, FY + 66, FY + 99, FY + HEAD]
for x in COLS[1:-1]:
    c.line(x, FY, x, FY + HEAD, sw=1.0)
for y in ROWS[1:-1]:
    c.line(FX, y, FX + FW, y, sw=1.0)

c.text(FX + 8, FY + 20, "USED AT:", size=11)
c.text(COLS[1] + 8, FY + 20, "AUTHOR: Федоров М.С.", size=11)
c.text(COLS[2] + 8, FY + 20, "DATE: 07.11.2026", size=11)
c.text(COLS[3] + 8, FY + 20, "WORKING", size=11)
c.text(COLS[4] + 8, FY + 20, "READER", size=11)
c.text(COLS[5] + 8, FY + 20, "DATE", size=11)
c.text(COLS[6] + 8, FY + 20, "CONTEXT:", size=11)

c.text(COLS[1] + 8, FY + 53, "PROJECT: Онлайн-магазин сотовых телефонов", size=11)
c.text(COLS[2] + 8, FY + 53, "REV: 07.11.2026", size=11)
c.text(COLS[3] + 8, FY + 53, "DRAFT", size=11)

c.text(COLS[1] + 8, FY + 86, "NOTES: 1 2 3 4 5 6 7 8 9 10", size=11)
c.text(COLS[3] + 8, FY + 86, "RECOMMENDED", size=11)

c.text(COLS[3] + 8, FY + 119, "PUBLICATION", size=11)

c.text(COLS[6] + 8, FY + 60, "TOP", size=20, bold=True)
c.text(COLS[6] + 8, FY + 84, "верхний уровень", size=10, italic=True)

# ---------------------------------------------------------------- подвал
FY0 = FY + FH - FOOT
c.line(FX, FY0, FX + FW, FY0, sw=1.4)
c.line(FX + 195, FY0, FX + 195, FY + FH, sw=1.0)
c.line(FX + 885, FY0, FX + 885, FY + FH, sw=1.0)
c.text(FX + 8, FY0 + 16, "NODE:", size=10)
c.text(FX + 40, FY0 + 48, "A-0", size=17, bold=True)
c.text(FX + 203, FY0 + 16, "TITLE:", size=10)
c.text(FX + 195 + 345, FY0 + 48, "Онлайн-магазин сотовых телефонов",
       size=16, anchor="middle")
c.text(FX + 893, FY0 + 16, "NUMBER:", size=10)
c.text(FX + 925, FY0 + 48, "1", size=17, bold=True)

# ---------------------------------------------------------------- блок A-0
BX0, BY0, BX1, BY1 = 430, 480, 810, 1050
c.rect(BX0, BY0, BX1 - BX0, BY1 - BY0, sw=2.0)
c.text((BX0 + BX1) / 2, 752, "Онлайн-магазин", size=21, anchor="middle", bold=True)
c.text((BX0 + BX1) / 2, 785, "сотовых телефонов", size=21, anchor="middle", bold=True)

# ---------------------------------------------------------------- входы
INPUTS = [
    "Список товаров для заказа у поставщика",
    "Прайс-лист",
    "Каталог товаров",
    "Данные о клиенте",
    "Товар со склада",
    "Документация пользователя",
    "Остаток на складе",
    "Сообщение об оплате",
    "Заявка клиента на товар",
]
IN_STEP = 60
IN_TOP = 510
for i, label in enumerate(INPUTS):
    y = IN_TOP + i * IN_STEP
    c.arrow([(258, y), (BX0, y)], direction="right")
    lines = wrap(label, 200, 14)
    for j, ln in enumerate(lines):
        c.text(50, y - 9 - (len(lines) - 1 - j) * 17, ln, size=14)

# ---------------------------------------------------------------- управление
CONTROLS = [("Данные о поставщиках", 520), ("Законодательство", 720)]
for label, x in CONTROLS:
    c.arrow([(x, 250), (x, BY0)], direction="down")
    c.text(x + 8, 272, label, size=14)

# ---------------------------------------------------------------- выходы
OUTPUTS = [
    ("Документы на товар", 560),
    ("Проданный товар", 680),
    ("Остаток товара на складе", 800),
    ("Статистика", 920),
]
for label, y in OUTPUTS:
    c.arrow([(BX1, y), (1015, y)], direction="right")
    c.text(822, y - 10, label, size=14)

# ---------------------------------------------------------------- механизмы
MECHANISMS = [("Персонал", 500), ("Клиент", 620), ("ПО", 740)]
for label, x in MECHANISMS:
    c.arrow([(x, 1190), (x, BY1)], direction="up")
    c.text(x + 8, 1212, label, size=14)

c.save("диаграмма_IDEF0_A0.svg")


# =====================================================================
# 2. Дерево узлов
# =====================================================================
W2, H2 = 1100, 350
t = Canvas(W2, H2)
t.text(W2 / 2, 40, "Дерево узлов IDEF0-модели", size=20, anchor="middle", bold=True)

# корень
RX0, RX1 = 360, 740
RY0, RY1 = 75, 135
t.rect(RX0, RY0, RX1 - RX0, RY1 - RY0, sw=1.6)
t.text((RX0 + RX1) / 2, 112, "A-0  Онлайн-магазин сотовых телефонов",
       size=16, anchor="middle", bold=True)

children = [
    ("A1", "Принять заказ"),
    ("A2", "Проверить наличие товара"),
    ("A3", "Оформить и оплатить заказ"),
    ("A4", "Организовать доставку"),
    ("A5", "Вести учёт и статистику"),
]
BW, BH, GAP = 186, 92, 16
total = len(children) * BW + (len(children) - 1) * GAP
start = (W2 - total) / 2
CY0 = 225
BUS = 185

# соединения
t.line((RX0 + RX1) / 2, RY1, (RX0 + RX1) / 2, BUS, sw=1.3)
centers = [start + i * (BW + GAP) + BW / 2 for i in range(len(children))]
t.line(min(centers), BUS, max(centers), BUS, sw=1.3)
for cx in centers:
    t.line(cx, BUS, cx, CY0, sw=1.3)

for i, (code, name) in enumerate(children):
    x = start + i * (BW + GAP)
    t.rect(x, CY0, BW, BH, sw=1.4)
    t.text(x + BW / 2, CY0 + 25, code, size=15, anchor="middle", bold=True)
    lines = wrap(name, BW - 12, 14)
    for j, ln in enumerate(lines):
        t.text(x + BW / 2, CY0 + 53 + j * 19, ln, size=14, anchor="middle")

t.save("дерево_узлов_IDEF0.svg")
print("done")
