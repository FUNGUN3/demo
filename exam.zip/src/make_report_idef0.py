# -*- coding: utf-8 -*-
"""Отчёт по практической работе 1.6 (IDEF0, контекстная диаграмма A-0).

Сокращённая версия: все разделы изложены тезисно.
"""

import os

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = "Times New Roman"

DOCX_NAME = "Отчет_ПР1.6_IDEF0_контекстная_диаграмма.docx"

doc = Document()

# ------------------------------------------------------------------ страница
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.top_margin, sec.bottom_margin = Cm(2), Cm(2)
sec.left_margin, sec.right_margin = Cm(3), Cm(1.5)


# ------------------------------------------------------------------ стили
def set_font(style, size=14, bold=False):
    style.font.name = FONT
    style.font.size = Pt(size)
    style.font.bold = bold
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    for attr in ('w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'):
        rfonts.set(qn(attr), FONT)
    lang = rpr.find(qn('w:lang'))
    if lang is None:
        lang = OxmlElement('w:lang')
        rpr.append(lang)
    lang.set(qn('w:val'), 'ru-RU')
    lang.set(qn('w:eastAsia'), 'ru-RU')


normal = doc.styles['Normal']
set_font(normal, 14)
normal.paragraph_format.line_spacing = 1.5
normal.paragraph_format.space_after = Pt(0)
normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
normal.paragraph_format.first_line_indent = Cm(1.25)

for name, size in (('Heading 1', 18), ('Heading 2', 14)):
    st = doc.styles[name]
    set_font(st, size, bold=True)
    st.font.color.rgb = None
    st.paragraph_format.first_line_indent = Cm(0)
    st.paragraph_format.space_before = Pt(12 if name == 'Heading 1' else 8)
    st.paragraph_format.space_after = Pt(6)
    st.paragraph_format.line_spacing = 1.5
    st.paragraph_format.keep_with_next = True


# ------------------------------------------------------- параметры документа
def _setting(tag, val=None):
    el = OxmlElement(tag)
    if val is not None:
        el.set(qn('w:val'), val)
    return el


_settings = doc.settings.element
_anchor = _settings.find(qn('w:defaultTabStop'))
_elements = [_setting('w:autoHyphenation', '1'),
             _setting('w:hyphenationZone', '284'),
             _setting('w:doNotHyphenateCaps')]
if _anchor is not None:
    prev = _anchor
    for el in _elements:
        prev.addnext(el)
        prev = el
else:
    for el in _elements:
        _settings.append(el)


# ------------------------------------------------------------------ утилиты
def p(parts, *, align=None, first_line=None, left=None, space_before=None,
      space_after=None, size=None, keep=False):
    par = doc.add_paragraph()
    if isinstance(parts, str):
        parts = [(parts, False)]
    for text, bold in parts:
        r = par.add_run(text)
        r.bold = bold
        if size:
            r.font.size = Pt(size)
    if align is not None:
        par.alignment = align
    if first_line is not None:
        par.paragraph_format.first_line_indent = Cm(first_line)
    if left is not None:
        par.paragraph_format.left_indent = Cm(left)
    if space_before is not None:
        par.paragraph_format.space_before = Pt(space_before)
    if space_after is not None:
        par.paragraph_format.space_after = Pt(space_after)
    if keep:
        par.paragraph_format.keep_with_next = True
    return par


def bullet(parts, left=1.25):
    par = doc.add_paragraph()
    par.paragraph_format.left_indent = Cm(left)
    par.paragraph_format.first_line_indent = Cm(-0.5)
    par.paragraph_format.line_spacing = 1.5
    par.paragraph_format.space_after = Pt(0)
    par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if isinstance(parts, str):
        parts = [(parts, False)]
    par.add_run("–\t")
    for text, bold in parts:
        r = par.add_run(text)
        r.bold = bold
    return par


def heading(text, new_page=False):
    h = doc.add_heading(text, level=1)
    if new_page:
        h.paragraph_format.page_break_before = True
    return h


def subheading(text):
    return doc.add_heading(text, level=2)


def page_break():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


def page_number_footer():
    footer = sec.footer
    par = footer.paragraphs[0]
    par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    par.paragraph_format.first_line_indent = Cm(0)
    r1 = par.add_run()
    b = OxmlElement('w:fldChar')
    b.set(qn('w:fldCharType'), 'begin')
    r1._r.append(b)
    r2 = par.add_run()
    instr = OxmlElement('w:instrText')
    instr.set(qn('xml:space'), 'preserve')
    instr.text = 'PAGE'
    r2._r.append(instr)
    r3 = par.add_run()
    e = OxmlElement('w:fldChar')
    e.set(qn('w:fldCharType'), 'end')
    r3._r.append(e)
    for r in (r1, r2, r3):
        r.font.size = Pt(12)
        r.font.name = FONT


def figure(filename, width_cm, caption):
    pic = doc.add_paragraph()
    pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.paragraph_format.first_line_indent = Cm(0)
    pic.paragraph_format.space_before = Pt(6)
    pic.paragraph_format.space_after = Pt(2)
    pic.add_run().add_picture(os.path.join(BASE, filename), width=Cm(width_cm))
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.first_line_indent = Cm(0)
    cap.paragraph_format.space_after = Pt(12)
    r = cap.add_run(caption)
    r.italic = True
    r.font.size = Pt(12)


page_number_footer()

# ================================================================== титул
p("Отчёт по практической работе № 1.6", align=WD_ALIGN_PARAGRAPH.CENTER,
  first_line=0, space_before=90, space_after=10)
p("«Построение концептуальной диаграммы соподчинённости систем модели IDEF0»",
  align=WD_ALIGN_PARAGRAPH.CENTER, first_line=0, space_after=150)

p("Выполнил:", align=WD_ALIGN_PARAGRAPH.LEFT, first_line=0, left=9.0)
p("Группа: 4-ИСП9-46", align=WD_ALIGN_PARAGRAPH.LEFT, first_line=0, left=9.0)
p("Студент: Федоров М.С.", align=WD_ALIGN_PARAGRAPH.LEFT, first_line=0, left=9.0)

p("Москва 2026 г.", align=WD_ALIGN_PARAGRAPH.CENTER, first_line=0, space_before=300)

# ================================================================== цель
goal = p([("Цель работы: ", True),
          ("изучение методологии IDEF0 и построение контекстной диаграммы A-0 "
           "информационной системы «Онлайн-магазин сотовых телефонов».", False)],
         first_line=0, size=16, space_after=10)
goal.paragraph_format.page_break_before = True

p("Задачи работы:", first_line=0, space_before=6, keep=True)
for item in [
    "изучить элементы и правила нотации IDEF0;",
    "классифицировать потоки системы по правилу ICOM;",
    "построить диаграмму A-0 и оформить отчёт.",
]:
    bullet(item)

# ================================================================== 1
heading("1. Теоретические сведения о методологии IDEF0")

p("IDEF0 — методология функционального моделирования, развитие подхода SADT. "
  "Система описывается как совокупность функций, а модель строится как иерархия "
  "диаграмм: на верхнем уровне — контекстная диаграмма A-0 с единственным блоком, "
  "задающим границы системы, ниже — диаграммы декомпозиции с блоками A1, A2 и т. д.")

p("Элементы нотации — блок (функция, имя — глагол) и стрелки-потоки. Стороны "
  "блока образуют правило ICOM:")
bullet([("I (Input, слева)", True), (" — входы, преобразуемые функцией;", False)])
bullet([("C (Control, сверху)", True),
        (" — управление: правила и нормативы, не расходуемые функцией;", False)])
bullet([("O (Output, справа)", True), (" — результаты;", False)])
bullet([("M (Mechanism, снизу)", True),
        (" — ресурсы и средства выполнения.", False)])

p("Правила построения: 3–6 блоков на диаграмме; блоки именуются глаголами, "
  "стрелки — существительными; у функции есть вход и выход; стрелки не "
  "изолированы; сохраняется баланс потоков между уровнями; диаграмма оформляется "
  "в рамке с реквизитами (автор, проект, дата, ревизия, статус, контекст, номер).",
  space_before=6)

p("Дерево узлов — иерархический перечень функций, служащий оглавлением модели и "
  "средством проверки её полноты. Кроме того, IDEF0 является средством "
  "коммуникации участников разработки (раздел 6).")

# ================================================================== 2
heading("2. Анализ предметной области и главная функция системы")

p("Онлайн-магазин сотовых телефонов — информационная система, в которой клиент "
  "выбирает модель в каталоге, оформляет заявку, оплачивает и получает товар; "
  "магазин взаимодействует с поставщиками, складом, платёжной системой и службой "
  "доставки. Главная функция — «Продавать сотовые телефоны через интернет-магазин»; "
  "на диаграмме блок назван по теме работы.")
p("Границы модели — от заявки клиента до выдачи товара и формирования отчётности; "
  "поставщики, банк и доставка рассматриваются как внешние сущности. Компоненты "
  "размещаются на сервере, АРМ персонала, клиентских устройствах, платёжном шлюзе "
  "и складской подсистеме.")

# ================================================================== 3
heading("3. Классификация потоков системы")

p("Потоки разделены на четыре группы по сторонам блока A-0: входы преобразуются "
  "функцией, управление ограничивает её выполнение, выходы являются результатом, "
  "механизмы — средствами выполнения.")

subheading("3.1. Входы (левая сторона)")
for name, note in [
    ("Список товаров для заказа у поставщика", "заявка на пополнение ассортимента"),
    ("Прайс-лист", "закупочные цены и условия поставки"),
    ("Каталог товаров", "модели и характеристики телефонов"),
    ("Данные о клиенте", "ФИО, контакты и адрес доставки"),
    ("Товар со склада", "товар, передаваемый клиенту"),
    ("Документация пользователя", "инструкции и гарантийные документы"),
    ("Остаток на складе", "данные о наличии товара"),
    ("Сообщение об оплате", "подтверждение платежа"),
    ("Заявка клиента на товар", "оформленный заказ покупателя"),
]:
    bullet([(name, True), (f" — {note};", False)])

subheading("3.2. Выходы (правая сторона)")
for name, note in [
    ("Документы на товар", "чек, накладная, гарантийный талон"),
    ("Проданный товар", "товар, переданный клиенту"),
    ("Остаток товара на складе", "данные о наличии после продажи"),
    ("Статистика", "отчёты о продажах и выручке"),
]:
    bullet([(name, True), (f" — {note};", False)])

subheading("3.3. Управление (верхняя сторона)")
for name, note in [
    ("Данные о поставщиках", "договоры и условия поставки"),
    ("Законодательство", "законы о защите прав потребителей и персональных данных"),
]:
    bullet([(name, True), (f" — {note};", False)])

subheading("3.4. Механизмы (нижняя сторона)")
for name, note in [
    ("Персонал", "менеджеры, кладовщики и курьеры"),
    ("Клиент", "оформляет заказ и получает товар"),
    ("ПО", "интернет-магазин, CRM, складская система, платёжный шлюз"),
]:
    bullet([(name, True), (f" — {note};", False)])

p("Клиент одновременно является источником входного потока «Заявка клиента на "
  "товар» и механизмом выполнения функций.", space_before=6)

# ================================================================== 4
heading("4. Построение контекстной диаграммы A-0")

p("Диаграмма построена в стандартной рамке SADT: создан макет, в центре размещён "
  "блок A-0, снизу подписаны механизмы, справа — выходы, сверху — управление, "
  "слева — входы; проверены ортогональность линий и отсутствие изолированных "
  "стрелок.")

page_break()
figure("диаграмма_IDEF0_A0.png", 15.6,
       "Рисунок 1 — Контекстная диаграмма IDEF0 (A-0) системы "
       "«Онлайн-магазин сотовых телефонов»")

p("Рамка содержит поля USED AT, AUTHOR, PROJECT, DATE, REV, NOTES, статус "
  "(WORKING / DRAFT / RECOMMENDED / PUBLICATION), READER, CONTEXT: TOP, а также "
  "NODE: A-0, TITLE и NUMBER. Диаграмма сохранена в форматах SVG и PNG.")

# ================================================================== 5
heading("5. Дерево узлов")

p("Блок A-0 раскрыт на пять функций: A1 «Принять заказ», A2 «Проверить наличие "
  "товара», A3 «Оформить и оплатить заказ», A4 «Организовать доставку», A5 «Вести "
  "учёт и статистику». Количество блоков (5) соответствует рекомендуемому "
  "диапазону 3–6, а порядок отражает логику обслуживания заказа.")

figure("дерево_узлов_IDEF0.png", 16.2,
       "Рисунок 2 — Дерево узлов IDEF0-модели")

p("Каждая функция наследует ICOM-потоки блока A-0, что обеспечивает баланс "
  "стрелок между уровнями модели.")

# ================================================================== 6
heading("6. Передача информации между участниками разработки модели")

p("Средства IDEF0 обеспечивают передачу информации между участниками разработки "
  "следующим образом:")
bullet("единая нотация и правило ICOM исключают разночтения при чтении диаграммы;")
bullet("рамка фиксирует автора, версию, статус и адресата документа;")
bullet("нумерация блоков и дерево узлов позволяют однозначно ссылаться на функцию;")
bullet("глоссарий закрепляет единые определения функций и потоков;")
bullet("анкеты и рецензирование обеспечивают итеративное уточнение модели;")
bullet("туннелирование скрывает несущественные потоки и снижает информационный шум.")

# ================================================================== 7
heading("7. Ответы на контрольные вопросы")

subheading("1. Для чего нужно дерево узлов?")
p("Дерево узлов служит оглавлением модели: оно показывает уровни декомпозиции, "
  "позволяет быстро найти нужную диаграмму и проверить полноту модели — какие "
  "блоки ещё не раскрыты.")

subheading("2. Какое может быть успешное решение проблем при построении диаграммы?")
p("Согласование цели и границ модели с заказчиком, предварительный список функций "
  "и потоков, ограничение 3–5 блоков на диаграмме, глагольные имена блоков, "
  "проверка баланса стрелок и итерационное рецензирование.")

subheading("3. Перечислите свойства и правила построения диаграмм")
p("Свойства: функциональная направленность, иерархичность, семантика ICOM, "
  "самодокументируемость. Правила: 3–6 блоков, нумерация A0/A1/A11, глаголы для "
  "блоков и существительные для стрелок, наличие входа и выхода, отсутствие "
  "изолированных стрелок, баланс потоков, туннелирование, заполненная рамка.")

# ================================================================== 8
heading("8. Вывод")

p("Изучена методология IDEF0 и построена контекстная диаграмма A-0 системы "
  "«Онлайн-магазин сотовых телефонов». Выделены 9 входов, 4 выхода, 2 управляющих "
  "воздействия и 3 механизма, построено дерево узлов с пятью функциями первого "
  "уровня. Диаграмма оформлена по правилам нотации и может служить основой для "
  "дальнейшей декомпозиции и проектирования системы.")

# ================================================================== источники
heading("Список использованных источников")
for item in [
    "Федорова Г. Н. Осуществление интеграции программных модулей : учебник для "
    "студ. учреждений сред. проф. образования / Г. Н. Федоров. — 2-е изд., стер. — "
    "Москва : Издательский центр «Академия», 2023. — 288 с.",
    "Гагарина Л. Г. Технология разработки программного обеспечения : учебное "
    "пособие / Л. Г. Гагарина, Е. В. Кокорева, Б. Д. Сидорова-Виснадул ; под ред. "
    "Л. Г. Гагариной. — Москва : ФОРУМ : ИНФРА-М, 2023. — 400 с. — ISBN "
    "978-5-8199-0812-9.",
]:
    par = doc.add_paragraph()
    par.paragraph_format.first_line_indent = Cm(1.25)
    par.paragraph_format.line_spacing = 1.5
    par.paragraph_format.space_after = Pt(0)
    par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    par.add_run(item)

doc.save(os.path.join(BASE, DOCX_NAME))
print("saved", DOCX_NAME)
