import os
import win32com.client as win32

base = r"C:\Users\user\Desktop\ДИАГРМАМЫ"
docx = os.path.join(base, "Отчет_ПР_UML_диаграмма_классов_онлайн_магазин.docx")
pdf = os.path.join(base, "Отчет_ПР_UML_диаграмма_классов_онлайн_магазин.pdf")

word = win32.Dispatch("Word.Application")
word.Visible = False
word.DisplayAlerts = 0
doc = word.Documents.Open(docx)
doc.SaveAs([pdf], FileFormat=17)
print("pages:", doc.ComputeStatistics(2))
doc.Close(False)
word.Quit()
print("ok")
