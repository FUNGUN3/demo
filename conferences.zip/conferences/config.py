"""Настройки приложения «Конференции.РФ»."""

# Параметры подключения к PostgreSQL
DB_SETTINGS = {
    "host": "localhost",
    "port": 5432,
    "dbname": "conferences",
    "user": "conf_user",
    "password": "conf_pass",
}

# Секретный ключ нужен Flask для работы сессий (входа в систему)
SECRET_KEY = "conferences-2027-secret"
